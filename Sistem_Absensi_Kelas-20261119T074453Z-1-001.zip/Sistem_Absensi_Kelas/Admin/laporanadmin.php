<?php
session_start();
// Pastikan path ke Koneksi.php benar
include '../Koneksi.php'; 

// 🔒 Cek apakah sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../Login2/login.php?pesan=belum_login");
    exit();
}

// Ambil username dari session (misal: Admin)
$username = $_SESSION['username'];

// **********************************************
// START: LOGIKA PENGAMBILAN DATA PENGGUNA UNTUK NAVBAR
// **********************************************
$query = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username' LIMIT 1");
$userData = mysqli_fetch_assoc($query); 

if (!$userData) {
    session_destroy();
    header("Location: ../Login2/login.php?pesan=user_tidak_ditemukan");
    exit();
}

$foto_db = $userData['foto_profil'] ?? null;
$inisial = strtoupper(substr($username, 0, 1));
$is_using_placeholder = (empty($foto_db) || $foto_db == 'default.png'); 

if (!$is_using_placeholder) {
    // Asumsi folder img/profil berada satu tingkat di atas folder admin
    $foto_profil_path = '../img/profil/' . $foto_db; 
} else {
    $foto_profil_path = ''; // Kosong jika menggunakan placeholder
}
// **********************************************
// END: LOGIKA PENGAMBILAN DATA PENGGUNA UNTUK NAVBAR
// **********************************************


// **********************************************
// START: LOGIKA LAPORAN REKAPITULASI SEMUA SISWA UNTUK ADMIN
// * **********************************************

// Query untuk merekapitulasi kehadiran (Hadir, Izin, Sakit, Tidak Hadir) per siswa
$sql_rekap_all = "
    SELECT 
        nama,
        COUNT(CASE WHEN status = 'Hadir' THEN 1 END) AS jumlah_hadir,
        COUNT(CASE WHEN status = 'Izin' THEN 1 END) AS jumlah_izin,
        COUNT(CASE WHEN status = 'Sakit' THEN 1 END) AS jumlah_sakit,
        COUNT(CASE WHEN status = 'Tidak Hadir' THEN 1 END) AS jumlah_tidak_hadir
    FROM siswa 
    GROUP BY nama
    ORDER BY nama ASC
"; 

$result_rekap = mysqli_query($conn, $sql_rekap_all);
$data_rekap_siswa = [];

if ($result_rekap) {
    while ($row = mysqli_fetch_assoc($result_rekap)) {
        // Gabungkan Izin dan Sakit menjadi satu kolom (Izin/Sakit)
        $jumlah_izin_sakit = $row['jumlah_izin'] + $row['jumlah_sakit'];
        $total_absen = $row['jumlah_hadir'] + $jumlah_izin_sakit + $row['jumlah_tidak_hadir'];
        
        $persentase_hadir = ($total_absen > 0) ? round(($row['jumlah_hadir'] / $total_absen) * 100, 1) : 0;

        $data_rekap_siswa[] = [
            'nama' => $row['nama'],
            'hadir' => $row['jumlah_hadir'],
            'izin_sakit' => $jumlah_izin_sakit,
            'tidak_hadir' => $row['jumlah_tidak_hadir'],
            'total' => $total_absen,
            'persentase_hadir' => $persentase_hadir
        ];
    }
}

// Menghitung TOTAL Keseluruhan Absensi (Statistik Global)
$total_hadir_global = array_sum(array_column($data_rekap_siswa, 'hadir'));
$total_izin_sakit_global = array_sum(array_column($data_rekap_siswa, 'izin_sakit'));
$total_tidak_hadir_global = array_sum(array_column($data_rekap_siswa, 'tidak_hadir'));
$total_absen_global = $total_hadir_global + $total_izin_sakit_global + $total_tidak_hadir_global;


if ($conn) mysqli_close($conn);

// **********************************************
// END: LOGIKA LAPORAN REKAPITULASI SEMUA SISWA UNTUK ADMIN
// **********************************************
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Admin - Total Jumlah Kehadiran</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js"></script>
    <style>
        /* ==================== 1. VARIABEL & RESET ==================== */
        :root {
            /* Warna Primer/Teks */
            --primary-color: #212529; 
            --secondary-color: #343a40; 
            --background-color: #F5F5F5; 
            --navbar-bg: #FFFFFF; /* PUTIH */
            --text-color: #333333;
            --shadow: 0 4px 8px rgba(0,0,0,0.08);
            --card-bg: #ffffff;

            /* Warna Status */
            --hadir-color: #198754; /* Hijau (Disesuaikan dengan Bootstrap 5 Success) */
            --izin-color: #ffc107; /* Kuning (Warning) */
            --alpha-color: #dc3545; /* Merah (Danger) */
        }
        
        * {margin:0; padding:0; box-sizing:border-box;}
        body {
            font-family: 'Poppins', sans-serif; 
            background: var(--background-color); 
            min-height:100vh; 
            color: var(--text-color);
        }

        /* ==================== 2. NAVBAR STYLE (Diperbaiki agar konsisten) ==================== */
        .navbar {
            display:flex; align-items:center; justify-content:space-between; 
            background: var(--navbar-bg); 
            padding:10px 40px; position:sticky; top:0; z-index:100; 
            box-shadow:0 2px 4px rgba(0,0,0,0.1); 
            border-bottom: 1px solid #eee;
        }
        .logo-area {display: flex; align-items: center;}
        .logo {font-size:24px; font-weight:700; color: var(--primary-color); letter-spacing:1px; margin-left: 5px;}
        .logo-area i {color: var(--primary-color); font-size: 28px;}
        .nav-links {list-style:none; display:flex; margin-left: 30px; margin-right: auto;}
        .nav-links li {margin: 0 15px;}
        .nav-links li a {
            color: var(--primary-color); 
            text-decoration: none; 
            border-bottom: 3px solid transparent; 
            padding-bottom: 10px;
            font-weight: 600; 
            transition: border-color 0.3s, color 0.3s;
        }
        .nav-links li a:hover {
            border-bottom-color: #aaa;
        }
        .nav-links li .active {
            font-weight: 700; 
            color: var(--primary-color);
            border-bottom-color: var(--primary-color);
        }

        /* Profil Area (Gaya Placeholder Hitam & Dropdown Rapi) */
        .profile-area {display: flex; align-items: center;}
        .profile {position:relative;}
        .profile img, .profile-picture-container {
            width:45px; height:45px; border-radius:50%; cursor:pointer; 
            background-color: var(--primary-color); /* Latar belakang hitam */
            color: white; 
            border:3px solid var(--primary-color); 
            display: flex; align-items: center; justify-content: center;
            font-weight: 600; font-size: 1.2em;
            box-shadow: 0 0 0 3px rgba(0,0,0,0.1); 
        }
        .dropdown {
            display:none; opacity: 0; 
            transform: translateY(5px); 
            transition: opacity 0.3s ease-out, transform 0.3s ease-out;
            position:absolute; right:0; top: 55px; 
            background:white; min-width:200px; 
            border-radius:10px; overflow:hidden; 
            box-shadow:0 8px 16px rgba(0,0,0,0.2); 
            border: 1px solid #ddd; z-index: 99;
        }
        .dropdown.active {
            display:block; opacity: 1; transform: translateY(0);
        }
        /* Style Link Biasa */
        .dropdown a {
            display:block; padding:12px 18px; color:#333; text-decoration:none; 
            font-weight:500; transition: background-color 0.2s;
            font-size: 14px;
        }
        .dropdown a:hover {
            background-color: #f1f1f1; 
        }
        /* Info Box */
        .dropdown .user-info-box {
            padding: 10px 18px 5px;
            font-size: 0.9em;
            color: #6c757d;
            border-bottom: 1px solid #eee;
            font-weight: 500;
        }
        /* Link Logout */
        .dropdown .logout-link {
             padding: 10px 18px 12px;
             font-weight: 600;
             color: var(--alpha-color);
        }
        .dropdown .logout-link:hover {
             background-color: #fce8e8;
        }
        
        /* ==================== 3. KONTEN UTAMA (Laporan Admin) ==================== */
        .container {
            max-width: 1200px;
            margin: 40px auto; 
            padding: 0 20px; 
        }
        h1 {
            color: var(--secondary-color);
            margin-bottom: 30px;
            font-size: 2em;
            border-bottom: 3px solid var(--primary-color);
            padding-bottom: 10px;
        }
        .summary-card {
            background-color: var(--card-bg);
            padding: 30px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }
        .summary-card h2 {
            font-size: 1.5em;
            margin-bottom: 20px;
            color: var(--text-color);
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        .chart-container {
            width: 100%;
            height: 350px; 
            margin-bottom: 30px;
        }

        /* --- Tabel Data Siswa --- */
        .table-container {
            overflow-x: auto;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: var(--card-bg);
            box-shadow: var(--shadow);
            border-radius: 8px;
            overflow: hidden; 
        }
        .data-table th, .data-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        .data-table th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.9em;
        }
        .data-table tr:hover {
            background-color: #f1f1f1;
        }
        .data-table td.hadir { color: var(--hadir-color); font-weight: 600; }
        .data-table td.izin { color: var(--izin-color); font-weight: 600; }
        .data-table td.alpha { color: var(--alpha-color); font-weight: 600; }
        .data-table td.total { font-weight: 700; background-color: #f8f9fa; }

        .progress-bar {
            height: 10px;
            background-color: var(--hadir-color);
            border-radius: 5px;
            transition: width 0.5s ease-in-out;
        }
        .progress-bar-container-cell {
            background-color: #e9ecef;
            border-radius: 5px;
            overflow: hidden;
            width: 100px;
        }
        
        @media (max-width: 768px) {
            .navbar{padding: 10px 20px;}
            .nav-links{display: none;}
            .container { padding: 20px; margin: 20px auto; }
            .data-table th, .data-table td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="logo-area">
        <i class="fas fa-chart-line"></i>
        <div class="logo">AdminPanel</div>
    </div>
    <ul class="nav-links">
        <li><a href="Admin.php">Dashboard</a></li>  
        <li><a href="laporanadmin.php" class="active">Laporan</a></li>
    </ul>
    <div class="profile-area">
        <div class="profile">
            <?php if ($is_using_placeholder): ?>
                <div class="profile-picture-container" id="profile-trigger">
                    <?= htmlspecialchars($inisial) ?>
                </div>
            <?php else: ?>
                <img src="<?= htmlspecialchars($foto_profil_path) ?>" 
                    alt="Profil <?= htmlspecialchars($username) ?>" 
                    id="profile-trigger">
            <?php endif; ?>
                    
            <div class="dropdown" id="profile-dropdown">
                <div class="user-info-box">Profil Admin (<small><?= htmlspecialchars($username) ?></small>)</div>
                <a href="../profil_admin/profil.php">Lihat Profil</a>
                <a href="../Login2/logout.php" class="logout-link">Logout</a>
            </div>
        </div>
    </div>
</nav>

<div class="container">
    <h1><i class="fas fa-chart-area"></i> Laporan Total Jumlah Kehadiran Siswa</h1>

    <div class="summary-card">
        <h2>Total Keseluruhan Siswa</h2>
        <p style="margin-bottom: 10px; font-weight: 500;">Total Absensi yang Tercatat di Seluruh Siswa:</p>
        <div class="chart-container">
            <canvas id="kehadiranChart"></canvas>
        </div>
        <div style="display: flex; justify-content: space-around; text-align: center; margin-top: 10px;">
            <div style="color: var(--hadir-color);">Hadir: **<?php echo $total_hadir_global; ?>**</div>
            <div style="color: var(--izin-color);">Izin/Sakit: **<?php echo $total_izin_sakit_global; ?>**</div>
            <div style="color: var(--alpha-color);">Tidak Hadir: **<?php echo $total_tidak_hadir_global; ?>**</div>
        </div>
    </div>
    
    <div class="summary-card">
        <h2>Rekapitulasi Kehadiran Tiap Siswa</h2>
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama Siswa</th>
                        <th>Hadir</th>
                        <th>Izin/Sakit</th>
                        <th>Tidak Hadir</th>
                        <th>Total Absen</th>
                        <th>Persentase Hadir</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($data_rekap_siswa as $data): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td>**<?php echo htmlspecialchars($data['nama']); ?>**</td>
                        <td class="hadir"><?php echo $data['hadir']; ?></td>
                        <td class="izin"><?php echo $data['izin_sakit']; ?></td>
                        <td class="alpha"><?php echo $data['tidak_hadir']; ?></td>
                        <td class="total"><?php echo $data['total']; ?></td>
                        <td>
                            <div class="progress-bar-container-cell">
                                <div class="progress-bar" style="width: <?php echo $data['persentase_hadir']; ?>%;"></div>
                            </div>
                            <small><?php echo $data['persentase_hadir']; ?>%</small>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($data_rekap_siswa)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 20px;">Belum ada data absensi yang tercatat di tabel **`siswa`**.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <p style="text-align: center; margin-top: 30px; color: #777;">Data diambil dari ringkasan absensi seluruh siswa di sistem (Tabel **`siswa`**).</p>

</div>

<script>
    // === 1. LOGIKA JAVASCRIPT: Dropdown Profil ===
    document.addEventListener('DOMContentLoaded', function() {
        const profileTrigger = document.getElementById('profile-trigger');
        const profileDropdown = document.getElementById('profile-dropdown');
        const profileArea = document.querySelector('.profile');

        if (profileTrigger && profileDropdown && profileArea) {
            profileTrigger.addEventListener('click', function(e) {
                e.stopPropagation();
                // Toggle kelas 'active' pada dropdown
                profileDropdown.classList.toggle('active');
            });

            document.addEventListener('click', function(e) {
                // Sembunyikan dropdown jika klik di luar area profil
                if (profileDropdown.classList.contains('active') && !profileArea.contains(e.target)) {
                    profileDropdown.classList.remove('active');
                }
            });
        }

        // === 2. LOGIKA JAVASCRIPT: Diagram Chart.js (Global Summary) ===
        const ctx = document.getElementById('kehadiranChart').getContext('2d');
        
        // Data diambil dari PHP (Total Global)
        const dataGlobal = {
            hadir: <?php echo $total_hadir_global; ?>,
            izin: <?php echo $total_izin_sakit_global; ?>,
            tidakHadir: <?php echo $total_tidak_hadir_global; ?>
        };

        const kehadiranChart = new Chart(ctx, {
            type: 'bar', // Menggunakan Diagram Batang (Bar Chart)
            data: {
                labels: ['Hadir', 'Izin/Sakit', 'Tidak Hadir'],
                datasets: [{
                    label: 'Total Absensi',
                    data: [dataGlobal.hadir, dataGlobal.izin, dataGlobal.tidakHadir],
                    backgroundColor: [
                        '#198754', // Hadir (Hijau)
                        '#ffc107', // Izin/Sakit (Kuning)
                        '#dc3545'  // Tidak Hadir (Merah)
                    ],
                    borderColor: [
                        '#1e7e34',
                        '#d39e00',
                        '#bd2130'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Jumlah Absensi'
                        },
                        ticks: {
                            precision: 0
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'Grafik Total Jumlah Seluruh Siswa/Siswi',
                        font: {
                            size: 16,
                            weight: '600',
                            family: 'Poppins'
                        }
                    }
                }
            }
        });
    });
</script>
</body>
</html>