<?php
include '../Koneksi.php';
$id = $_GET['id'] ?? null;

if ($id && mysqli_query($conn, "DELETE FROM siswa WHERE id=$id")) {
    header("Location: Admin.php");
} else {
    echo "Gagal menghapus data!";
}
exit;
?>
