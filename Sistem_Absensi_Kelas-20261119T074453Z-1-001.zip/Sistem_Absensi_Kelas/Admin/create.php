<?php
include '../Koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $jam_masuk = $_POST['jam_masuk'];
    $status = $_POST['status'];
    $alasan = $_POST['alasan'];
    $tanggal = $_POST['tanggal'];

    $query = "INSERT INTO siswa (nama, kelas, jam_masuk, status, alasan, tanggal)
              VALUES ('$nama', '$kelas', '$jam_masuk', '$status', '$alasan', '$tanggal')";

    if (mysqli_query($conn, $query)) {
        header("Location: Admin.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Absensi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:#eef1f5;">
<div class="container mt-5 bg-white p-4 rounded shadow">
    <h4 class="mb-4">Tambah Data Absensi</h4>
    <form method="POST">
        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Kelas</label>
            <select name="kelas" class="form-select" required>
                <option value="" disabled selected>Pilih Kelas</option>
                <option value="X.1">X.1</option>
                <option value="X.2">X.2</option>
                <option value="X.3">X.3</option>
                <option value="XI.1">XI.1</option>
                <option value="XI.2">XI.2</option>
                <option value="XI.3">XI.3</option>
                <option value="XII.1">XII.1</option>
                <option value="XII.2">XII.2</option>
                <option value="XII.3">XII.3</option>
            </select>
        </div>
        <div class="mb-3">
            <label>Jam Masuk</label>
            <input type="time" name="jam_masuk" class="form-control">
        </div>
        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-select" required>
                <option value="Hadir">Hadir</option>
                <option value="Sakit">Sakit</option>
                <option value="Izin">Izin</option>
                
            </select>
        </div>
        <div class="mb-3">
            <label>Alasan</label>
            <input type="text" name="alasan" class="form-control">
        </div>
        <div class="mb-3">
            <label>Tanggal</label>
            <input type="date" name="tanggal" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="Admin.php" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>
