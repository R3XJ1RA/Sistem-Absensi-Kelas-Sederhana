<?php
// Mulai session untuk mengambil data pengguna untuk Navbar
session_start();
// Hubungkan ke database (Pastikan path file Koneksi.php benar)
include '../Koneksi.php'; 

// 🔒 Cek apakah sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../Login2/login.php?pesan=belum_login");
    exit();
}

// Ambil username dari session (misal: Admin)
$username = $_SESSION['username'];

// **********************************************
// START: LOGIKA PENGAMBILAN DATA PENGGUNA UNTUK NAVBAR
// **********************************************
$query = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username' LIMIT 1");
$userData = mysqli_fetch_assoc($query); 

if (!$userData) {
    session_destroy();
    header("Location: ../Login2/login.php?pesan=user_tidak_ditemukan");
    exit();
}

$foto_db = $userData['foto_profil'] ?? null;
$inisial = strtoupper(substr($username, 0, 1));
$is_using_placeholder = (empty($foto_db) || $foto_db == 'default.png'); 

if (!$is_using_placeholder) {
    $foto_profil_path = '../img/profil/' . $foto_db; 
} else {
    $foto_profil_path = ''; 
}
// **********************************************
// END: LOGIKA PENGAMBILAN DATA PENGGUNA UNTUK NAVBAR
// **********************************************

// 1. Ambil query pencarian dari URL
$search_query = isset($_GET['q']) ? mysqli_real_escape_string($conn, $_GET['q']) : '';

// Tentukan apakah mode review izin sedang aktif
$is_review_mode = isset($_GET['review']) && $_GET['review'] === 'true';

// 2. Hitung statistik keseluruhan (Tidak terpengaruh oleh pencarian)
$total_siswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(DISTINCT nama) AS total FROM siswa"))['total'];
$total_hadir = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM siswa WHERE status='Hadir'"))['total'];
$total_tidak_hadir = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM siswa WHERE status IN ('Sakit','Izin')"))['total'];

// ⭐️ LOGIKA NOTIFIKASI REVIEW IZIN (Menghitung yang BELUM di-review) ⭐️
$sql_review_izin_count = "SELECT COUNT(*) AS total FROM siswa 
                          WHERE status IN ('Sakit', 'Izin') 
                          AND (alasan IS NULL OR alasan = '')";
$total_review_izin = mysqli_fetch_assoc(mysqli_query($conn, $sql_review_izin_count))['total'];
// ⭐️ END LOGIKA NOTIFIKASI ⭐️

// 3. Ambil data absensi dengan kondisi pencarian dan/atau mode review
$sql = "SELECT id, nama, kelas, jam_masuk, status, alasan, tanggal FROM siswa";

$where_clauses = [];

if (!empty($search_query)) {
    // Tambahkan klausa WHERE untuk memfilter data berdasarkan nama atau kelas
    $where_clauses[] = "(nama LIKE '%$search_query%' OR kelas LIKE '%$search_query%')";
}

if ($is_review_mode) {
    // 🔥 PERBAIKAN FILTER UTAMA: Hanya tampilkan status Sakit atau Izin (SEMUA data, tidak peduli alasan terisi atau tidak)
    $where_clauses[] = "status IN ('Sakit', 'Izin')";
}

if (!empty($where_clauses)) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}

// Jika tidak ada filter yang diterapkan, kueri akan mengambil semua data (Mode Normal)
$sql .= " ORDER BY tanggal DESC, jam_masuk DESC"; // Urutan tetap

$result = mysqli_query($conn, $sql);
if (!$result) {
    die("Query Error: " . mysqli_error($conn) . " SQL: " . $sql);
}

$main_url = "../";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard & Panel Admin - Sistem Absensi</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <style>
        /* ==================== 1. VARIABEL & RESET ==================== */
        :root {
            /* Warna Dasar */
            --primary-color: #212529; 
            --secondary-color: #343a40; 
            --background-color: #F5F5F5; 
            --navbar-bg: #FFFFFF; 
            --text-color: #333333;
            --shadow: 0 4px 8px rgba(0,0,0,0.08);

            /* Warna Kartu Statistik */
            --hadir-color: #198754; 
            --izin-color: #ffc107; 
            --jumlah-siswa-color: #0d6efd; 
            --alpha-color: #dc3545; 
            --light-grey-outline: #ced4da; 
        }
        
        * {margin:0; padding:0; box-sizing:border-box;}
        body {
            font-family: 'Poppins', sans-serif; 
            background: var(--background-color); 
            min-height:100vh; 
            color: var(--text-color);
        }

        /* ==================== 2. NAVBAR STYLE ==================== */
        .navbar {
            display:flex; align-items:center; justify-content:space-between; 
            background: var(--navbar-bg); 
            padding:10px 40px; position:sticky; top:0; z-index:100; 
            box-shadow:0 2px 4px rgba(0,0,0,0.1); 
            border-bottom: 1px solid #eee;
        }
        .logo-area {display: flex; align-items: center;}
        .logo {
            font-size:24px; font-weight:700; 
            color: var(--primary-color); 
            letter-spacing:1px; 
            margin-left: 5px; 
        }
        .logo-area i {color: var(--primary-color); font-size: 28px;}
        .nav-links {list-style:none; display:flex; margin-right: auto; margin-left: 30px;} 
        .nav-links li {margin: 0 15px;}
        .nav-links li a {
            color: var(--primary-color); 
            text-decoration: none; 
            border-bottom: 3px solid transparent; 
            padding-bottom: 10px;
            font-weight: 600; 
            transition: border-color 0.3s, color 0.3s;
        }
        .nav-links li a:hover {
            border-bottom-color: #aaa;
        }
        .nav-links li .active {
            font-weight: 700; 
            color: var(--primary-color);
            border-bottom-color: var(--primary-color); 
        }
        .profile-area {display: flex; align-items: center;}
        .profile {position:relative;}
        .profile img, .profile-picture-container {
            width:45px; height:45px; border-radius:50%; cursor:pointer; 
            background-color: var(--primary-color); 
            color: white; 
            border:3px solid var(--primary-color); 
            transition: box-shadow 0.2s;
            display: flex; align-items: center; justify-content: center;
            font-weight: 600; font-size: 1.2em;
            box-shadow: 0 0 0 3px rgba(0,0,0,0.1); 
        }
        .profile-picture-container:hover {
            box-shadow: 0 0 0 5px rgba(0,0,0,0.15);
        }
        .dropdown {
            display:none; opacity: 0; 
            transform: translateY(5px); 
            transition: opacity 0.3s ease-out, transform 0.3s ease-out;
            position:absolute; right:0; top: 55px; 
            background:white; min-width:200px; 
            border-radius:10px; overflow:hidden; 
            box-shadow:0 8px 16px rgba(0,0,0,0.2); 
            border: 1px solid #ddd; z-index: 99;
        }
        .dropdown.active {
            display:block; opacity: 1; transform: translateY(0);
        }
        .dropdown a {
            display:block; padding:12px 18px; color:#333; text-decoration:none; 
            font-weight:500; transition: background-color 0.2s;
            font-size: 14px;
        }
        .dropdown a:hover {
            background-color: #f1f1f1; 
        }
        .dropdown .user-info {
            padding: 10px 18px 5px;
            font-size: 0.9em;
            color: #6c757d;
            border-bottom: 1px solid #eee;
        }
        .dropdown .logout-link {
             padding: 10px 18px 12px;
             font-weight: 600;
             color: var(--alpha-color);
        }
        .dropdown .logout-link:hover {
             background-color: #fce8e8;
        }


        /* ==================== 3. KONTEN UTAMA ==================== */
        .container {
            max-width: 1200px; 
            margin: 20px auto; 
            padding: 0 20px; 
        }

        /* Kartu Statistik */
        .card-row {
            display: flex;
            flex-wrap: wrap;
            margin: 0 -10px; 
        }

        .card-col {
            flex: 1 1 300px; 
            margin: 0 10px 20px 10px;
        }

        .card {
            border: none;
            border-radius: 12px;
            box-shadow: var(--shadow);
            color: white; 
        }
        
        .card.bg-primary { background-color: var(--jumlah-siswa-color) !important;}
        .card.bg-success { background-color: var(--hadir-color) !important;}
        .card.bg-warning { 
            background-color: var(--izin-color) !important;
            color: #333333 !important;
        }
        .card.bg-warning .card-body, .card.bg-warning .card-footer {
            color: #333333 !important;
        }

        .card-body {
            padding: 1rem 1.2rem;
            font-size: 1.1em;
            font-weight: 500;
        }
        .card-footer {
            padding: 0.8rem 1.2rem;
            background: rgba(255, 255, 255, 0.2);
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            font-size: 1.5em;
            font-weight: 700;
            border-radius: 0 0 12px 12px;
        }

        /* Judul Konten */
        h3, h4, h5 {
            font-weight: 700 !important;
            color: var(--secondary-color);
        }
        
        /* Filter & Aksi Cepat (Menggunakan gaya manual) */
        .action-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
            margin-bottom: 20px;
        }
        .search-form {
            display: flex;
            flex-grow: 1;
            gap: 5px;
        }
        .form-control {
            padding: 10px 15px;
            border: 1px solid var(--light-grey-outline);
            border-radius: 8px;
            flex-grow: 1;
        }
        .btn {
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s, color 0.2s, border-color 0.2s;
        }
        
        /* 🔥 Tombol Kelola Siswa/Kembali: Selalu outline/secondary */
        .btn-outline-secondary {
            color: var(--secondary-color);
            border: 1px solid var(--light-grey-outline);
            background-color: white;
        }
        .btn-outline-secondary:hover {
            background-color: #eee;
            color: var(--secondary-color);
        }
        /* End Tombol Kelola Siswa */

        .btn-outline-success {
            color: var(--primary-color);
            border: 1px solid var(--primary-color);
            background-color: white;
        }
        .btn-outline-success:hover {
            background-color: var(--primary-color);
            color: white;
        }
        .btn-outline-danger {
            color: var(--alpha-color);
            border: 1px solid var(--alpha-color);
            background-color: white;
        }
        .btn-outline-danger:hover {
            background-color: var(--alpha-color);
            color: white;
        }
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
            border: 1px solid var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--secondary-color);
        }
        .btn-info {
            background-color: #0dcaf0;
            color: white;
            border: 1px solid #0dcaf0;
        }
        .btn-danger {
            background-color: var(--alpha-color);
            color: white;
            border: 1px solid var(--alpha-color);
        }
        /* --- Tambahan Gaya untuk Tombol Review Izin (Kuning Solid) --- */
        .btn-warning-solid {
            background-color: var(--izin-color);
            color: #333333; /* Warna teks gelap */
            border: 1px solid var(--izin-color);
        }
        .btn-warning-solid:hover {
            background-color: #e6b000; /* Warna kuning sedikit lebih gelap saat hover */
            color: #333333;
        }
        /* Log Absensi Tabel */
        .data-table-section {
            background-color: var(--card-bg);
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-top: 20px;
        }
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
        }
        .table-responsive {
            overflow-x: auto;
            padding: 0 20px 20px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        .table thead th {
            font-weight: 600;
            text-transform: uppercase;
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
            padding: 12px 15px;
            text-align: left;
        }
        .table tbody tr:hover {
            background-color: #f1f1f1;
        }
        .table td {
            padding: 12px 15px;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }

        /* Badge Status Kustom */
        .badge {
            padding: 0.3em 0.6em;
            border-radius: 0.375rem;
            font-weight: 600;
            font-size: 0.85em;
        }
        .badge.bg-success { background-color: var(--hadir-color) !important; color: white !important;}
        .badge.bg-warning { background-color: var(--izin-color) !important; color: #333 !important;}
        .badge.bg-info { background-color: #0dcaf0 !important; color: white !important;}
        .badge.bg-danger { background-color: var(--alpha-color) !important; color: white !important;}

        /* ==================== MODIFIKASI UKURAN TOMBOL AKSI BARU ==================== */
        .table-responsive .btn-sm {
            /* Ukuran tombol 34x34px */
            width: 34px; 
            height: 34px;
            padding: 0; 
            display: inline-flex; 
            align-items: center; 
            justify-content: center;
            border-radius: 6px; 
            font-size: 0.9rem; 
            line-height: 1; 
        }

        /* Jarak antar tombol 8px */
        .table-responsive .btn-info {
            margin-right: 8px !important; 
        }

        /* Pastikan kolom Aksi tidak terlalu lebar */
        .table thead th:last-child,
        .table tbody td:last-child {
            width: 90px; 
            white-space: nowrap; 
        }
        /* =========================================================================== */

        @media (max-width: 768px) {
            .navbar{padding: 10px 20px;}
            .nav-links{display: none;}
            .container { padding: 20px; margin: 20px auto; }
            .card-col { flex: 1 1 100%; }
            .action-container { flex-direction: column; align-items: stretch; }
            .search-form { width: 100%; }
            .table td, .table th { padding: 8px 10px; font-size: 0.9em; }
        }
    </style>
</head>

<body>

<nav class="navbar">
    <div class="logo-area">
        <i class="fas fa-chart-line"></i>
        <div class="logo">AdminPanel</div>
    </div>
    <ul class="nav-links">
        <li><a href="Admin.php"class="active">Dashboard</a></li>
        <li><a href="laporanadmin.php">Laporan</a></li>
    </ul>
    <div class="profile-area">
        <div class="profile">
            <?php if ($is_using_placeholder): ?>
                <div class="profile-picture-container" id="profile-trigger">
                    <?= htmlspecialchars($inisial) ?>
                </div>
            <?php else: ?>
                <img src="<?= htmlspecialchars($foto_profil_path) ?>" 
                    alt="Profil <?= htmlspecialchars($username) ?>" 
                    id="profile-trigger">
            <?php endif; ?>
                    
            <div class="dropdown" id="profile-dropdown">
                <div class="user-info">Profil Admin (<small><?= htmlspecialchars($username) ?></small>)</div>
                <a href="../profil_admin/profil.php">Lihat Profil</a>
                <a href="../Login2/logout.php" class="logout-link">Logout</a>
            </div>
        </div>
    </div>
</nav>

<div class="container">

    <h3 class="mb-4 fw-bold"><i class="fas fa-tachometer-alt me-2"></i> Dashboard Absensi</h3>
    
    <div class="card-row">
        <div class="card-col">
            <div class="card bg-primary">
                <div class="card-body">Total Siswa</div>
                <div class="card-footer"><strong><?= $total_siswa ?> orang</strong></div>
            </div>
        </div>
        <div class="card-col">
            <div class="card bg-success">
                <div class="card-body">Total Hadir</div>
                <div class="card-footer"><strong><?= $total_hadir ?> orang</strong></div>
            </div>
        </div>
        <div class="card-col">
            <div class="card bg-warning">
                <div class="card-body">Tidak Hadir (Sakit/Izin)</div>
                <div class="card-footer"><strong><?= $total_tidak_hadir ?> orang</strong></div>
            </div>
        </div>
    </div>
    
    <div class="mt-3">
        <h5 class="fw-bold text-dark mb-3">Filter & Aksi Cepat</h5>
        
        <div class="action-container">
            <form class="search-form" role="search" id="searchForm">
                <input class="form-control" type="search" name="q" 
                        placeholder="Cari Nama Siswa atau Kelas..." 
                        aria-label="Search" value="<?= htmlspecialchars($search_query) ?>">
                <button class="btn btn-outline-success" type="submit"><i class="fas fa-search"></i> Cari</button>
                
                <?php if (!empty($search_query)): ?>
                    <a href="Admin.php<?= $is_review_mode ? '?review=true' : '' ?>" class="btn btn-outline-danger"><i class="fas fa-times"></i> Reset Cari</a>
                <?php endif; ?>
            </form>
            
            <a href="laporanadmin.php" class="btn btn-outline-secondary">
                <i class="fas fa-chart-bar me-2"></i> Laporan
            </a>
            
            <?php if ($is_review_mode): ?>
                <a href="Admin.php" class="btn btn-outline-secondary">
                    <i class="fas fa-users me-2"></i> Kelola Siswa (Kembali)
                </a>
            <?php else: ?>
                 <a href="data_siswa.php" class="btn btn-outline-secondary">
                    <i class="fas fa-users me-2"></i> Kelola Siswa
                </a>
            <?php endif; ?>
            
            <a href="Admin.php?review=true" class="btn btn-warning-solid">
                <i class="fas fa-paper-plane me-2"></i> Review Izin
                
                <?php if ($total_review_izin > 0): ?>
                    <span class="badge rounded-pill bg-danger ms-1">
                        <?= $total_review_izin ?>
                    </span>
                <?php endif; ?>
            </a>
        </div>
    </div>


    <div class="data-table-section">
        <div class="table-header"> 
            <h4 class="fw-bold mb-0">
                <?php if ($is_review_mode): ?>
                    <i class="fas fa-bell me-2 text-warning"></i> Daftar Siswa Izin/Sakit (Semua Keterangan)
                <?php else: ?>
                    Log Absensi Siswa
                <?php endif; ?>
                
                <?php if (!empty($search_query)): ?>
                    <small class="text-secondary fs-6">(Hasil untuk: "<?= htmlspecialchars($search_query) ?>")</small>
                <?php endif; ?>
            </h4>

            <a href="create.php" class="btn btn-primary"> <i class="bi bi-plus-circle me-1"></i> Tambah Absensi
            </a>
        </div>

        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama</th>
                        <th>Kelas</th>
                        <th>Jam Masuk</th>
                        <th>Status</th>
                        <th>Alasan</th>
                        <th style="width:130px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                        $no = 1;
                        while ($row = mysqli_fetch_assoc($result)) {
                            $jam_masuk = $row['jam_masuk'] ? date('H:i', strtotime($row['jam_masuk'])) : '-';
                            $tanggal = date('d-m-Y', strtotime($row['tanggal']));

                            $statusClass = match ($row['status']) {
                                'Hadir' => 'success',
                                'Sakit' => 'warning',
                                'Izin'  => 'info',
                                default => 'secondary'
                            };

                            // Menampilkan pesan berbeda untuk kolom Alasan saat belum ada keterangan
                            $alasan_tampil = htmlspecialchars($row['alasan'] ?: '*** BELUM ADA KETERANGAN ***');

                            // Tentukan apakah ini adalah baris yang perlu di-review (untuk penandaan visual)
                            $needs_review = ($row['status'] == 'Sakit' || $row['status'] == 'Izin') && (empty($row['alasan']));
                            
                            // Baris diwarnai jika needs_review (ini bisa diterapkan di kedua mode jika diinginkan)
                            $row_class = ($needs_review) ? 'table-warning' : '';


                            echo "
                            <tr class='{$row_class}'>
                                <td>{$no}</td>
                                <td>{$tanggal}</td>
                                <td>" . htmlspecialchars($row['nama']) . "</td>
                                <td>" . htmlspecialchars($row['kelas']) . "</td>
                                <td>{$jam_masuk}</td>
                                <td><span class='badge bg-{$statusClass}'>" . htmlspecialchars($row['status']) . "</span></td>
                                <td>{$alasan_tampil}</td>
                                <td>
                                    <a href='update.php?id={$row['id']}' class='btn btn-sm btn-info'>
                                        <i class='bi bi-pencil-square'></i>
                                    </a>
                                    <a href='delete.php?id={$row['id']}' class='btn btn-sm btn-danger'
                                        onclick='return confirm(\"Yakin ingin menghapus data ini?\")'>
                                        <i class='bi bi-trash'></i>
                                    </a>
                                </td>
                            </tr>";
                            $no++;
                        }
                    } else {
                        $colspan = 8;
                        $message = "Belum ada data absensi.";
                        if (!empty($search_query)) {
                            $message = "Data absensi untuk **\"" . htmlspecialchars($search_query) . "\"** tidak ditemukan.";
                        } elseif ($is_review_mode) {
                             // Pesan ini muncul jika tidak ada siswa dengan status Izin/Sakit sama sekali
                             $message = "🎉 Saat ini tidak ada siswa dengan status Izin atau Sakit.";
                        }
                        echo "<tr><td colspan='{$colspan}' class='text-center py-4'>{$message}</td></tr>";
                    }

                    mysqli_close($conn);
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
    // === LOGIKA JAVASCRIPT: Dropdown Profil ===
    document.addEventListener('DOMContentLoaded', function() {
        const profileTrigger = document.getElementById('profile-trigger');
        const profileDropdown = document.getElementById('profile-dropdown');
        const profileArea = document.querySelector('.profile');

        if (profileTrigger && profileDropdown && profileArea) {
            profileTrigger.addEventListener('click', function(e) {
                e.stopPropagation();
                profileDropdown.classList.toggle('active');
            });

            document.addEventListener('click', function(e) {
                if (profileDropdown.classList.contains('active') && !profileArea.contains(e.target)) {
                    profileDropdown.classList.remove('active');
                }
            });
        }

        // Script untuk menangani form pencarian
        const searchForm = document.getElementById('searchForm');
        if (searchForm) {
            searchForm.addEventListener('submit', function(event) {
                event.preventDefault();
                
                const searchValue = this.querySelector('input[name="q"]').value.trim();
                let url = window.location.pathname + '?q=' + encodeURIComponent(searchValue);
                
                // Pertahankan mode review jika sedang aktif saat melakukan pencarian
                const urlParams = new URLSearchParams(window.location.search);
                if (urlParams.get('review') === 'true') {
                    url += '&review=true';
                }

                window.location.href = url;
            });
        }
    });
</script>

</body>
</html>