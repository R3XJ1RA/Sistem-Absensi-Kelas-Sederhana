<?php
include '../Koneksi.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID tidak valid");
}

$id = (int) $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM siswa WHERE id=$id");
$data = mysqli_fetch_assoc($result);

if (!$data) {
    die("Data tidak ditemukan");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $kelas = mysqli_real_escape_string($conn, $_POST['kelas']);
    $jam_masuk = $_POST['jam_masuk'];
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $alasan = mysqli_real_escape_string($conn, $_POST['alasan']);
    $tanggal = $_POST['tanggal'];

    $query = "UPDATE siswa SET 
                nama='$nama', 
                kelas='$kelas', 
                jam_masuk='$jam_masuk', 
                status='$status', 
                alasan='$alasan', 
                tanggal='$tanggal' 
              WHERE id=$id";

    if (mysqli_query($conn, $query)) {
        header("Location: Admin.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Absensi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:#eef1f5;">
<div class="container mt-5 bg-white p-4 rounded shadow">
    <h4 class="mb-4">Edit Data Absensi</h4>
    <form method="POST">
        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($data['nama']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Kelas</label>
            <select name="kelas" class="form-select" required>
                <?php
                $kelasList = ['X.1','X.2','X.3','XI.1','XI.2','XI.3','XII.1','XII.2','XII.3'];
                foreach ($kelasList as $kelas) {
                    $selected = ($data['kelas'] == $kelas) ? 'selected' : '';
                    echo "<option value='$kelas' $selected>$kelas</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Jam Masuk</label>
            <input type="time" name="jam_masuk" class="form-control" value="<?= $data['jam_masuk'] ?>">
        </div>
        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-select" required>
                <?php
                $options = ['Hadir', 'Sakit', 'Izin'];
                foreach ($options as $opt) {
                    $selected = ($opt == $data['status']) ? 'selected' : '';
                    echo "<option value='$opt' $selected>$opt</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Alasan</label>
            <input type="text" name="alasan" class="form-control" value="<?= htmlspecialchars($data['alasan']) ?>">
        </div>
        <div class="mb-3">
            <label>Tanggal</label>
            <input type="date" name="tanggal" class="form-control" value="<?= $data['tanggal'] ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="Admin.php" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>
