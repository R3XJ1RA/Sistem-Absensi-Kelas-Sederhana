<?php
session_start();
include '../Koneksi.php';

// Ambil username dari session login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];

// Ambil data user dari database
$sql = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    // Jika data pengguna tidak ditemukan, keluar dan hancurkan session
    session_destroy();
    header("Location: ../Login2/login.php?pesan=user_tidak_ditemukan");
    exit;
}

// Data yang akan ditampilkan
$nama_lengkap = htmlspecialchars($user['nama_lengkap'] ?? $username);
$about_me = htmlspecialchars($user['about'] ?? 'Belum ada deskripsi.');
$jumlah_hadir = htmlspecialchars($user['jumlah_hadir'] ?? 0);
$jumlah_izin = htmlspecialchars($user['jumlah_izin'] ?? 0);
$jumlah_tidak_hadir = htmlspecialchars($user['jumlah_tidak_hadir'] ?? 0);

// Placeholder foto profil
$foto_url = 'https://placehold.co/100x100/CCCCCC/666666?text=' . strtoupper(substr($nama_lengkap, 0, 1));
if (!empty($user['foto'])) {
    $foto_url = htmlspecialchars($user['foto']); 
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Profil - <?php echo $nama_lengkap; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* ==================== VARIABLE & RESET ==================== */
        :root {
            --primary-color: #4CAF50; /* Hijau Utama */
            --secondary-color: #388E3C; /* Hijau Gelap */
            --background-color: #f5f5f5;
            --text-color: #333;
            --card-bg: #ffffff;
            --shadow: 0 4px 8px rgba(0,0,0,0.08);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--background-color);
            color: var(--text-color);
            min-height: 100vh;
        }

        /* ==================== TOP BAR (Disesuaikan) ==================== */
        .top-bar {
            background-color: var(--card-bg);
            padding: 15px 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: var(--shadow);
        }
        
        .top-bar-left {
            display: flex;
            align-items: center;
        }

        /* Gaya Logo Area */
        .logo-area {
            display: flex;
            align-items: center;
            margin-right: 30px; /* Jarak antara logo dan link navigasi pertama */
        }
        
        .logo-area i { 
            color: var(--primary-color); 
            font-size: 28px;
        }

        .logo { 
            font-weight: 700; 
            color: var(--secondary-color); 
            font-size: 1.2em;
            margin-left: 10px; /* Jarak antara ikon dan teks logo */
        }
        
        /* Gaya Tautan Navigasi (Home, Absensi, Profil Diri) */
        .top-bar-left a {
            margin-left: 20px;
            text-decoration: none;
            color: var(--primary-color); 
            font-weight: 600; 
            font-size: 16px; 
            padding-bottom: 2px;
            border-bottom: 2px solid transparent; 
            transition: color 0.3s, border-color 0.3s;
        }
        
        .top-bar-left a:hover,
        .top-bar-left a.active {
            color: var(--secondary-color); 
            border-bottom-color: var(--secondary-color);
            font-weight: 700;
        }
        
        /* Gaya Tautan Logout (Top Bar Right) */
        .top-bar-right a { 
            margin-right: 0;
            text-decoration: none;
            color: var(--text-color); 
            font-weight: 500;
            transition: color 0.2s;
            font-size: 16px;
        }
        
        /* Gaya Hover untuk Logout - WARNA HIJAU */
        .top-bar-right a:hover {
             color: var(--secondary-color);
        }

        /* ==================== PROFILE LAYOUT (Tidak berubah) ==================== */
        .profile-container {
            max-width: 1000px;
            margin: 40px auto;
            padding: 0 20px;
        }
        .profile-card {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            align-items: stretch;
        }
        .card {
            background-color: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
        }
        .profile-main { 
            flex: 1 1 300px; 
            align-items: center;
        }
        .user-details { 
            flex: 1 1 350px; 
        }
        .side-sections { 
            flex: 1 1 250px; 
        }

        /* ==================== PROFILE MAIN (LEFT) (Tidak berubah) ==================== */
        .avatar-area {
            text-align: center;
            margin-bottom: 20px;
        }
        .avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background-color: #e0e0e0;
            object-fit: cover;
            border: 3px solid var(--primary-color);
            display: block;
            margin: 0 auto;
        }
        .profile-main h1 {
            font-size: 1.5em;
            font-weight: 700;
            color: var(--secondary-color);
            margin-bottom: 25px;
            text-align: center;
        }

        /* ==================== ABOUT ME SECTION (Tidak berubah) ==================== */
        .section-title {
            font-size: 1.1em;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--text-color);
            border-bottom: 2px solid #eee;
            padding-bottom: 5px;
        }
        #about-text {
            min-height: 80px;
            color: #555;
            margin-bottom: 10px;
        }
        textarea {
            width: 100%;
            min-height: 100px;
            border: 1px solid #ccc;
            border-radius: 8px;
            resize: vertical;
            padding: 10px;
            font-family: 'Poppins', sans-serif;
            font-size: 0.9em;
        }
        .about-controls {
              margin-top: 15px; 
        }
        .btn-group {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        .btn {
            background-color: var(--primary-color);
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.2s;
            text-align: center;
            flex-grow: 1;
        }
        .btn:hover { background-color: var(--secondary-color); }
        .save-btn { flex-grow: 1; }
        .edit-btn { background-color: #5cb85c; }
        .edit-btn:hover { background-color: #449d44; }


        /* ==================== USER DETAILS & REKAP (Tidak berubah) ==================== */
        .user-details p, .side-sections p {
            margin-bottom: 8px;
            line-height: 1.5;
            font-size: 0.95em;
        }
        .user-details span, .side-sections strong {
            font-weight: 600;
            color: var(--secondary-color);
        }

        /* Media Query untuk Responsivitas (Tidak berubah) */
        @media (max-width: 900px) {
            .profile-card { flex-direction: column; }
            .top-bar { padding: 15px 20px; }
            .profile-main, .user-details, .side-sections { 
                flex-basis: auto; 
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="top-bar">
        <div class="top-bar-left">
            <div class="logo-area">
                <i class="fas fa-graduation-cap"></i>
                <div class="logo">AbsensiKelas</div>
            </div>
            <a href="http://localhost/Sistem_Absensi_Kelas/Home2/home2.php">Home</a>
            <a href="http://localhost/Sistem_Absensi_Kelas/halaman_utama/index.php">Absensi</a>
            <a href="#" class="active">Profil Diri</a> 
            <a href="http://localhost/Sistem_Absensi_Kelas/profil_diri/laporan.php">Laporan</a> 
        </div>
        <div class="top-bar-right">
            <a href="http://localhost/Sistem_Absensi_Kelas/Login2/logout.php">Logout <i class="fas fa-sign-out-alt"></i></a>
        </div>
    </div>

    <div class="profile-container">
        <h1>Profil Pengguna</h1>
        <div class="profile-card">
            
            <div class="card profile-main">
                <div class="avatar-area">
                    <img src="<?= $foto_url ?>" alt="Avatar" class="avatar">
                </div>
                
                <h1 style="color: var(--text-color);"><?php echo $nama_lengkap; ?></h1>
                
                <div class="section-title">About me</div>
                
                <div class="about-controls">
                    <p id="about-text"><?php echo $about_me; ?></p>
                    
                    <textarea id="about-input" style="display:none;"><?php echo htmlspecialchars($user['about'] ?? ''); ?></textarea>
                    
                    <div class="btn-group">
                        <button class="btn save-btn" id="save-btn" style="display:none;">Simpan</button>
                        <button class="btn edit-btn" id="edit-btn">Edit</button>
                    </div>
                </div>
            </div>

            <div class="card user-details">
                <div class="section-title">User details <i class="fas fa-id-card"></i></div>
                <p><strong>Username:</strong> <span><?php echo htmlspecialchars($username); ?></span></p>
                <p><strong>ID User:</strong> <span><?php echo $user['id_user'] ?? 'N/A'; ?></span></p>
                <p><strong>Role:</strong> <span><?php echo $user['role'] ?? 'Siswa'; ?></span></p>
                <p><strong>Negara:</strong> <span>Indonesia</span></p>
                <p><strong>Kota:</strong> <span>Sidoarjo</span></p>
                <p><strong>Zona Waktu:</strong> <span>WIB</span></p>
            </div>

            <div class="card side-sections">
                <div class="section-title">Rekap Kehadiran <i class="fas fa-clipboard-check"></i></div>
                <p>Jumlah Hadir: <strong><?php echo $jumlah_hadir; ?></strong></p>
                <p>Jumlah Izin: <strong><?php echo $jumlah_izin; ?></strong></p>
                <p>Jumlah Tidak Hadir: <strong><?php echo $jumlah_tidak_hadir; ?></strong></p>
            </div>
            
        </div>
    </div>

<script>
const editBtn = document.getElementById('edit-btn');
const saveBtn = document.getElementById('save-btn');
const aboutText = document.getElementById('about-text');
const aboutInput = document.getElementById('about-input');

// Menangani tombol Edit
editBtn.addEventListener('click', () => {
    aboutText.style.display = 'none';
    aboutInput.style.display = 'block';
    saveBtn.style.display = 'inline-block';
    editBtn.style.display = 'none';
    aboutInput.focus();
});

// Menangani tombol Simpan (Simulasi AJAX)
saveBtn.addEventListener('click', () => {
    const newAbout = aboutInput.value;
    
    saveBtn.innerText = 'Menyimpan...';
    saveBtn.disabled = true;

    // Asumsi file 'update_about.php' sudah ada dan berfungsi
    fetch('update_about.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'about=' + encodeURIComponent(newAbout)
    })
    .then(res => res.text())
    .then(data => {
        aboutText.innerHTML = newAbout.replace(/\n/g, "<br>");
        
        aboutText.style.display = 'block';
        aboutInput.style.display = 'none';
        saveBtn.style.display = 'none';
        editBtn.style.display = 'inline-block';
        
        saveBtn.innerText = 'Simpan';
        saveBtn.disabled = false;
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Gagal menyimpan perubahan. Cek koneksi server.');
        
        saveBtn.innerText = 'Simpan';
        saveBtn.disabled = false;
    });
});
</script>
</body>
</html>