<?php
session_start();
include '../Koneksi.php'; 

// Cek apakah sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../Login2/login.php?pesan=belum_login");
    exit();
}

$username = $_SESSION['username'];
$nama_lengkap = isset($_SESSION['nama_lengkap']) ? $_SESSION['nama_lengkap'] : $username;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaturan - Work In Progress</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4CAF50;
            --background-color: #F5F5F5;
            --text-color: #333333;
        }
        * {margin:0; padding:0; box-sizing:border-box;}
        body {
            font-family: 'Poppins', sans-serif; 
            background: var(--background-color); 
            color: var(--text-color);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            text-align: center;
        }
        .wip-container {
            background: white;
            padding: 50px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 90%;
            border-top: 5px solid var(--primary-color);
        }
        .wip-container i {
            font-size: 60px;
            color: var(--primary-color);
            margin-bottom: 20px;
        }
        .wip-container h1 {
            font-size: 2.2em;
            color: var(--text-color);
            margin-bottom: 10px;
            font-weight: 700;
        }
        .wip-container p {
            font-size: 1.1em;
            color: #777;
            margin-bottom: 25px;
        }
        .wip-container a {
            background-color: var(--primary-color);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: background-color 0.3s;
        }
        .wip-container a:hover {
            background-color: #388E3C;
        }
    </style>
</head>
<body>

<div class="wip-container">
    <i class="fas fa-tools"></i> <h1>Work In Progress</h1>
    <p>Mohon maaf, halaman **Pengaturan** saat ini sedang dalam tahap pengembangan dan akan segera tersedia.</p>
    <p>Terima kasih atas kesabaran Anda!</p>
    <a href="http://localhost/Sistem_Absensi_Kelas/Home2/home2.php">Kembali ke Dashboard</a>
</div>

</body>
</html>