<?php
session_start();
// Pastikan path ke Koneksi.php benar relatif terhadap lokasi file laporan.php
include '../Koneksi.php'; 

// 🔒 Cek apakah sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../Login2/login.php?pesan=belum_login");
    exit();
}

// Ambil username dari session (misal: Constantine)
$username = $_SESSION['username'];

// **********************************************
// START: LOGIKA PENGAMBILAN DATA PENGGUNA UNTUK NAVBAR DAN PROFIL
// **********************************************
// Ambil data user lengkap dari database
$query = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username' LIMIT 1");
$userData = mysqli_fetch_assoc($query); 

if (!$userData) {
    // Jika data user tidak ditemukan meskipun session ada
    session_destroy();
    header("Location: ../Login2/login.php?pesan=user_tidak_ditemukan");
    exit();
}

// Persiapan data untuk gambar profil atau inisial
$foto_db = $userData['foto_profil'] ?? null;
$inisial = strtoupper(substr($username, 0, 1));

// Tentukan apakah menggunakan gambar (img) atau placeholder (div inisial)
// ASUMSI: File gambar profil tersimpan di '../img/profil/'
$is_using_placeholder = (empty($foto_db) || $foto_db == 'default.png'); 

if (!$is_using_placeholder) {
    $foto_profil_path = '../img/profil/' . $foto_db; 
} else {
    // Jika menggunakan placeholder/default, path tidak diperlukan, tapi inisial sudah siap.
    $foto_profil_path = ''; 
}
// **********************************************
// END: LOGIKA PENGAMBILAN DATA PENGGUNA UNTUK NAVBAR DAN PROFIL
// **********************************************


// **********************************************
// START: LOGIKA LAPORAN KEHADIRAN
// **********************************************

// Menggunakan username sebagai identifier siswa
$nama_lengkap = $username; 

// Query untuk Menghitung Rekap Kehadiran dari tabel 'siswa'
// ASUMSI: Kolom 'nama' di tabel 'siswa' berisi nama yang sama dengan user yang login
$sql_rekap = "
    SELECT 
        COUNT(CASE WHEN status = 'Hadir' THEN 1 END) AS jumlah_hadir,
        COUNT(CASE WHEN status = 'Izin' THEN 1 END) AS jumlah_izin,
        COUNT(CASE WHEN status = 'Sakit' THEN 1 END) AS jumlah_sakit,
        COUNT(CASE WHEN status = 'Tidak Hadir' THEN 1 END) AS jumlah_tidak_hadir
    FROM siswa 
    WHERE nama = ?
"; 

// Menggunakan prepared statement untuk keamanan
$stmt = $conn->prepare($sql_rekap);

// Asumsi: Username sama dengan nama siswa yang diabsen di tabel 'siswa'
$siswa_identifier = $username; 

$stmt->bind_param("s", $siswa_identifier);
$stmt->execute();
$result = $stmt->get_result();
$rekap_data = $result->fetch_assoc();


// Proses Data Hasil Query
if (!$rekap_data) {
    $jumlah_hadir = 0;
    $jumlah_izin = 0;
    $jumlah_tidak_hadir = 0;
} else {
    // Kumpulkan Izin dan Sakit menjadi Izin/Sakit
    $jumlah_hadir = (int)($rekap_data['jumlah_hadir'] ?? 0);
    $jumlah_izin = (int)($rekap_data['jumlah_izin'] ?? 0) + (int)($rekap_data['jumlah_sakit'] ?? 0);
    $jumlah_tidak_hadir = (int)($rekap_data['jumlah_tidak_hadir'] ?? 0);
}

$total_kehadiran = $jumlah_hadir + $jumlah_izin + $jumlah_tidak_hadir;
$persentase_hadir = ($total_kehadiran > 0) ? round(($jumlah_hadir / $total_kehadiran) * 100, 1) : 0;

if ($stmt) $stmt->close();
if ($conn) $conn->close();

// **********************************************
// END: LOGIKA LAPORAN KEHADIRAN
// **********************************************
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Kehadiran - <?php echo $username; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* ==================== 1. VARIABEL & RESET ==================== */
        :root {
            --primary-color: #4CAF50; /* Hijau */
            --secondary-color: #388E3C; /* Hijau Gelap */
            --background-color: #F5F5F5; /* Abu Muda */
            --navbar-bg: #FFFFFF; 
            --text-color: #333333;
            --shadow: 0 4px 8px rgba(0,0,0,0.08);
            --card-bg: #ffffff;
            --hadir-color: #4CAF50;
            --izin-color: #FFC107;
            --alpha-color: #F44336;
        }
        
        * {margin:0; padding:0; box-sizing:border-box;}
        body {
            font-family: 'Poppins', sans-serif; 
            background: var(--background-color); 
            min-height:100vh; 
            color: var(--text-color);
        }

        /* ==================== 2. NAVBAR STYLE ==================== */
        .navbar {
            display:flex; align-items:center; justify-content:space-between; 
            background: var(--navbar-bg); 
            padding:10px 40px; position:sticky; top:0; z-index:100; 
            box-shadow:0 4px 6px rgba(0,0,0,0.05); 
        }
        .logo-area {display: flex; align-items: center;}
        .logo {font-size:24px; font-weight:700; color: var(--primary-color); letter-spacing:1px; margin-left: 10px;}
        .logo-area i {color: var(--primary-color); font-size: 28px;}
        .nav-links {list-style:none; display:flex;}
        .nav-links li {margin: 0 20px;}
        
        .nav-links li a {
            color: var(--primary-color); 
            text-decoration: none; 
            border-bottom: 2px solid transparent; 
            padding-bottom: 2px;
            font-weight: 600; 
            position: relative; 
            transition: border-color 0.3s, color 0.3s;
        }

        .nav-links li a:hover {
            color: var(--secondary-color); 
            border-bottom-color: var(--secondary-color);
        }

        .nav-links li .active {
            font-weight: 700; 
            color: var(--primary-color);
            border-bottom-color: var(--primary-color);
        }
        
        .profile-area {display: flex; align-items: center; gap: 20px;}
        
        /* === PROFILE DROPDOWN LOGIC & STYLE REVISI === */
        .profile {position:relative;}

        /* Styling untuk Gambar Profil dan Placeholder Inisial */
        .profile img, .profile-picture-container {
            width:45px; height:45px; 
            border-radius:50%; 
            cursor:pointer; 
            border:2px solid var(--primary-color); 
            object-fit: cover;
            transition: transform 0.2s, box-shadow 0.2s;
            /* Styling khusus untuk container inisial */
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
            font-size: 1.2em;
        }

        /* Animasi Hover Baru (Berlaku untuk img dan container) */
        .profile img:hover, .profile-picture-container:hover {
            transform: scale(1.05);
            box-shadow: 0 0 10px rgba(76, 175, 80, 0.6);
        }
        
        .dropdown {
            display:none; 
            opacity: 0;
            transform: translateY(-10px);
            transition: opacity 0.3s ease-out, transform 0.3s ease-out;
            
            position:absolute; right:0; top: 60px; 
            background:white; min-width:180px; 
            border-radius:10px; overflow:hidden; 
            box-shadow:0 12px 25px rgba(0,0,0,0.25); 
            border: 1px solid #eee;
            z-index: 99;
        }
        
        .dropdown.active {
            display:block; 
            opacity: 1;
            transform: translateY(0);
        }
        
        .dropdown a {
            display:block; padding:12px 18px; color:#333; text-decoration:none; 
            font-weight:500; 
            transition: background-color 0.2s, color 0.2s;
            font-size: 14px;
        }
        .dropdown a:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        /* ==================== 3. KONTEN UTAMA (Laporan) ==================== */
        .container {
            max-width: 900px;
            margin: 40px auto; 
            padding: 0 20px; 
        }
        h1 {
            color: var(--secondary-color);
            margin-bottom: 30px;
            font-size: 2em;
            border-bottom: 3px solid var(--primary-color);
            padding-bottom: 10px;
        }
        .recap-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .recap-card {
            background-color: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            text-align: center;
            transition: transform 0.2s;
        }
        .recap-card:hover {
            transform: translateY(-5px);
        }
        .recap-card i {
            font-size: 30px;
            margin-bottom: 10px;
        }
        .recap-card h3 {
            font-size: 1.1em;
            margin: 0 0 5px 0;
            font-weight: 600;
            color: #555;
        }
        .recap-card .count {
            font-size: 2.5em;
            font-weight: 700;
        }
        .hadir { border-left: 5px solid var(--hadir-color); }
        .hadir i, .hadir .count { color: var(--hadir-color); }
        .izin { border-left: 5px solid var(--izin-color); }
        .izin i, .izin .count { color: var(--izin-color); }
        .alpha { border-left: 5px solid var(--alpha-color); }
        .alpha i, .alpha .count { color: var(--alpha-color); }
        .total { border-left: 5px solid var(--secondary-color); }
        .total i, .total .count { color: var(--secondary-color); }
        .summary-card {
            background-color: var(--card-bg);
            padding: 30px;
            border-radius: 12px;
            box-shadow: var(--shadow);
        }
        .summary-card h2 {
            font-size: 1.5em;
            margin-bottom: 20px;
            color: var(--text-color);
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        .progress-bar-container {
            background-color: #e0e0e0;
            border-radius: 10px;
            height: 30px;
            overflow: hidden;
            margin-bottom: 15px;
        }
        .progress-bar {
            height: 100%;
            background-color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            transition: width 1s ease-in-out;
            text-align: right;
            padding-right: 10px;
        }
        .details-list {
            list-style: none;
            padding: 0;
            margin-top: 20px;
        }
        .details-list li {
            padding: 8px 0;
            border-bottom: 1px dashed #eee;
            display: flex;
            justify-content: space-between;
            font-weight: 500;
        }
        .details-list li:last-child {
            border-bottom: none;
            font-weight: 700;
            color: var(--secondary-color);
            font-size: 1.1em;
        }
        .details-list .status {
            font-weight: 700;
        }
        .details-list .status.hadir { color: var(--hadir-color); }
        .details-list .status.izin { color: var(--izin-color); }
        .details-list .status.alpha { color: var(--alpha-color); }
        
        @media (max-width: 600px) {
            .navbar{padding: 10px 20px;}
            .nav-links{display: none;} /* Sembunyikan link di layar kecil */
            .container { padding: 20px; margin: 20px auto; }
            .recap-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="logo-area">
        <i class="fas fa-graduation-cap"></i>
        <div class="logo">AbsensiKelas</div>
    </div>
    <ul class="nav-links">
        <li><a href="../Home2/home2.php">Home</a></li>
        <li><a href="../halaman_utama/index.php">Absensi</a></li>
        <li><a href="../profil_diri/profil.php">Profil Diri</a></li>
        <li><a href="laporan.php" class="active">Laporan</a></li>
    </ul>
    <div class="profile-area">
        <div class="profile">
            <?php if ($is_using_placeholder): ?>
                <div class="profile-picture-container" id="profile-trigger">
                    <?= htmlspecialchars($inisial) ?>
                </div>
            <?php else: ?>
                <img src="<?= htmlspecialchars($foto_profil_path) ?>" 
                     alt="Profil <?= htmlspecialchars($username) ?>" 
                     id="profile-trigger">
            <?php endif; ?>
                 
            <div class="dropdown" id="profile-dropdown">
                <a href="../profil_diri/profil.php">Profil Saya (<?= htmlspecialchars($username) ?>)</a>
                <a href="pengaturan.php">Pengaturan</a>
                <a href="../Login2/logout.php">Logout</a>
            </div>
        </div>
    </div>
</nav>
<div class="container">
    <h1><i class="fas fa-file-alt"></i> Laporan Kehadiran **<?php echo htmlspecialchars($username); ?>**</h1>

    <div class="recap-grid">
        <div class="recap-card hadir">
            <i class="fas fa-check-circle"></i>
            <h3>Hadir</h3>
            <div class="count"><?php echo $jumlah_hadir; ?></div>
        </div>
        
        <div class="recap-card izin">
            <i class="fas fa-pause-circle"></i>
            <h3>Izin/Sakit</h3>
            <div class="count"><?php echo $jumlah_izin; ?></div>
        </div>
        
        <div class="recap-card alpha">
            <i class="fas fa-times-circle"></i>
            <h3>Tidak Hadir</h3>
            <div class="count"><?php echo $jumlah_tidak_hadir; ?></div>
        </div>

        <div class="recap-card total">
            <i class="fas fa-list-ol"></i>
            <h3>Total Absen</h3>
            <div class="count"><?php echo $total_kehadiran; ?></div>
        </div>
    </div>

    <div class="summary-card">
        <h2>Ringkasan Kehadiran</h2>
        
        <p style="margin-bottom: 10px;">Persentase Kehadiran Murni:</p>
        <div class="progress-bar-container">
            <div class="progress-bar" style="width: <?php echo $persentase_hadir; ?>%;">
                <?php echo $persentase_hadir; ?>%
            </div>
        </div>

        <ul class="details-list">
            <li>Hadir <span class="status hadir"><?php echo $jumlah_hadir; ?></span></li>
            <li>Izin/Sakit <span class="status izin"><?php echo $jumlah_izin; ?></span></li>
            <li>Tidak Hadir <span class="status alpha"><?php echo $jumlah_tidak_hadir; ?></span></li>
            <li>Total Absensi <span class="status total"><?php echo $total_kehadiran; ?></span></li>
        </ul>
        
    </div>
    
    <p style="text-align: center; margin-top: 30px; color: #777;">Data diambil dari riwayat absensi Anda di sistem (Tabel **`siswa`**).</p>

</div>

<script>
    // === LOGIKA JAVASCRIPT: Mengubah Dropdown dari Hover ke Click ===
    document.addEventListener('DOMContentLoaded', function() {
        const profileTrigger = document.getElementById('profile-trigger');
        const profileDropdown = document.getElementById('profile-dropdown');
        const profileArea = document.querySelector('.profile');

        // 1. Toggle Dropdown saat tombol profil diklik
        profileTrigger.addEventListener('click', function(e) {
            e.stopPropagation(); // Mencegah event mencapai body saat mengklik tombol
            profileDropdown.classList.toggle('active');
        });

        // 2. Sembunyikan Dropdown saat mengklik di luar area dropdown
        document.addEventListener('click', function(e) {
            // Cek apakah yang diklik BUKAN bagian dari profile-area
            if (profileDropdown.classList.contains('active') && !profileArea.contains(e.target)) {
                profileDropdown.classList.remove('active');
            }
        });
    });
</script>
</body>
</html>