<?php
$host = 'localhost';
$user = 'root';
$pass = 'root'; // untuk MAMP biasanya password-nya 'root'
$db   = 'absensi_kelas';

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
