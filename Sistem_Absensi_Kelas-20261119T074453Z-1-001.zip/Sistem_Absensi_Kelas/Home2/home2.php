<?php
session_start();
include '../Koneksi.php'; // koneksi database

// 🔒 Cek apakah sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../Login2/login.php?pesan=belum_login");
    exit();
}

// Ambil data user dari session
$username = $_SESSION['username'];

// Ambil data user lengkap dari database
$query = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username' LIMIT 1");
$userData = mysqli_fetch_assoc($query); // Data lengkap user ada di sini!

// Jika user tidak ditemukan (misal dihapus dari database)
if (!$userData) {
    session_destroy();
    header("Location: ../Login2/login.php?pesan=user_tidak_ditemukan");
    exit();
}

// Ambil data penting dari database
$user_id = $userData['id_user'];
// Menggunakan $userData['foto'] jika ada, jika tidak menggunakan placeholder inisial
$foto_profil = !empty($userData['foto']) ? $userData['foto'] : "https://placehold.co/45x45/4CAF50/ffffff?text=" . strtoupper(substr($username, 0, 1));

// --- LOGIKA PHP UNTUK MEMBUAT DAFTAR KELAS (X.1 hingga XII.3) ---
$jenjang = ['X', 'XI', 'XII'];
$nomor_kelas = [1, 2, 3]; 
$daftar_kelas = [];

foreach ($jenjang as $j) {
    foreach ($nomor_kelas as $n) {
        $kelas_lengkap = "Kelas {$j} - {$n}"; 
        $file_jadwal = "jadwal.jpeg"; 
        $daftar_kelas[] = [
            'nama' => $kelas_lengkap,
            'file' => $file_jadwal
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Absensi Kelas</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* ==================== 1. VARIABEL & RESET ==================== */
        :root {
            --primary-color: #4CAF50; /* Hijau */
            --background-color: #F5F5F5; /* Abu Muda */
            --navbar-bg: #FFFFFF; 
            --text-color: #333333;
            --secondary-accent: #1A73E8; /* Biru */
        }
        
        * {margin:0; padding:0; box-sizing:border-box;}
        body {
            font-family: 'Poppins', sans-serif; 
            background: var(--background-color); 
            min-height:100vh; 
            color: var(--text-color);
        }

        /* ==================== 2. NAVBAR (REVISI) ==================== */
        .navbar {
            display:flex; align-items:center; justify-content:space-between; 
            background: var(--navbar-bg); 
            padding:10px 40px; position:sticky; top:0; z-index:100; 
            box-shadow:0 4px 6px rgba(0,0,0,0.05); 
        }
        .logo-area {display: flex; align-items: center;}
        .logo {font-size:24px; font-weight:700; color: var(--primary-color); letter-spacing:1px; margin-left: 10px;}
        .logo-area i {color: var(--primary-color); font-size: 28px;}
        .nav-links {list-style:none; display:flex;}
        .nav-links li {margin: 0 20px;}
        
        .nav-links li a {
            color: var(--primary-color); 
            text-decoration: none; /* Hapus underline default */
            border-bottom: 2px solid transparent; /* Garis bawah transparan untuk transisi */
            padding-bottom: 2px;
            font-weight: 600; 
            position: relative; 
            transition: border-color 0.3s, color 0.3s;
        }

        .nav-links li a:hover {
            color: #388E3C; 
            border-bottom-color: #388E3C;
        }

        .nav-links li .active {
            font-weight: 700; 
            color: var(--primary-color);
            border-bottom-color: var(--primary-color);
        }
        
        .profile-area {display: flex; align-items: center; gap: 20px;}
        
        /* Hapus .notification & .badge */
        
        /* === PROFILE DROPDOWN LOGIC & STYLE REVISI === */
        .profile {position:relative;}
        .profile img {
            width:45px; height:45px; border-radius:50%; cursor:pointer; 
            border:2px solid var(--primary-color); object-fit: cover;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        /* Animasi Hover Baru */
        .profile img:hover {
            transform: scale(1.05);
            box-shadow: 0 0 10px rgba(76, 175, 80, 0.6);
        }
        
        .dropdown {
            /* Awalnya tersembunyi */
            display:none; 
            opacity: 0;
            transform: translateY(-10px);
            transition: opacity 0.3s ease-out, transform 0.3s ease-out;
            
            position:absolute; right:0; top: 60px; /* Posisi di bawah gambar */
            background:white; min-width:180px; 
            border-radius:10px; overflow:hidden; 
            box-shadow:0 12px 25px rgba(0,0,0,0.25); 
            border: 1px solid #eee;
            z-index: 99;
        }
        
        /* Class yang ditambahkan oleh JS saat tombol diklik */
        .dropdown.active {
            display:block; 
            opacity: 1;
            transform: translateY(0);
        }
        
        .dropdown a {
            display:block; padding:12px 18px; color:#333; text-decoration:none; 
            font-weight:500; 
            transition: background-color 0.2s, color 0.2s;
            font-size: 14px;
        }
        .dropdown a:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        /* ==================== 3. MAIN CONTAINER & LAYOUT DUA KOLOM ==================== */
        .main-container {
            padding: 30px 40px; 
            max-width: 1400px; 
            margin: 0 auto; 
            display: flex; 
            gap: 30px;
        }
        .content-left {
            flex-grow: 1; 
            min-width: 60%;
        }
        .content-right { /* Sidebar untuk Recent Classes */
            width: 300px; 
            align-self: stretch; 
            display: flex;
            flex-direction: column;
        }

        /* Welcome Message */
        .welcome-title {color: var(--text-color); margin-bottom: 30px;}
        .welcome-title h1 {font-size: 32px; font-weight: 700; display: flex; align-items: center;}
        .welcome-title h1 span {margin-right: 15px; color: var(--primary-color);}
        .welcome-title p {font-size: 16px; font-weight: 400; color: #555;}
        
        /* ==================== 4. DAFTAR KELAS UTAMA (GRID) ==================== */
        .class-list-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
        }
        .class-list-container h2 {
            font-size: 22px;
            margin-bottom: 15px;
            color: var(--primary-color);
        }
        .grid-kelas {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); 
            gap: 15px;
        }
        .class-card-link {
            text-decoration: none;
            color: inherit;
            display: block;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .class-card-grid {
            background: var(--background-color); 
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            border: 1px solid #ddd;
            height: 100%;
            cursor: pointer;
        }
        .class-card-grid i {
            font-size: 30px;
            color: var(--primary-color); 
            margin-bottom: 5px;
        }
        .class-card-grid h4 {
            font-size: 16px;
            margin: 0;
            color: var(--text-color);
            font-weight: 600;
        }
        .class-card-grid p {
            font-size: 12px;
            color: #777;
            margin: 0;
        }
        .class-card-link:hover .class-card-grid {
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
            background: #E0E0E0;
        }
        
        /* ==================== 5. KELAS YANG BARU DIAKSES (SIDEBAR PANJANG) ==================== */
        .recent-classes {
            padding: 20px; 
            background: white; 
            border-radius: 15px; 
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            height: 100%; 
            display: flex;
            flex-direction: column;
        }
        .recent-classes h2 {
            color: var(--primary-color); 
            margin-bottom: 15px; 
            font-size: 18px; 
            border-bottom: 2px solid var(--primary-color); 
            padding-bottom: 8px;
            font-weight: 600;
        }
        .class-list {
            display: flex; 
            flex-direction: column; 
            gap: 15px; 
            flex-grow: 1; 
            padding-bottom: 20px;
        }
        .class-card {
            background: var(--background-color); 
            border-radius: 12px; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: background 0.2s;
            padding: 15px; 
            min-height: 70px; 
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .class-card:hover {
            background: #E0E0E0;
            cursor: pointer;
        }
        .class-card h4 {
            font-size: 16px; 
            color: var(--text-color); 
            margin: 0 0 4px 0;
            font-weight: 600;
        }
        .class-card p {
            font-size: 12px; 
            color: #777;
            margin: 0;
        }

        /* Tambahan: Kartu Dummy untuk mengisi ruang di sisi kanan */
        .dummy-card {
            background: #e9e9e9;
            border-radius: 12px;
            padding: 15px;
            text-align: center;
            color: #aaa;
            font-size: 14px;
            font-style: italic;
            border: 1px dashed #ccc;
            margin-top: auto; 
        }
        
        /* ==================== 6. MEDIA QUERIES ==================== */
        @media(max-width:1024px){
            .main-container{flex-direction: column;} 
            .content-right{width: 100%; margin-top: 30px;} 
            .navbar{padding: 10px 20px;}
            .nav-links{display: none;}
            .class-list {flex-direction: row; overflow-x: auto; padding-bottom: 10px; flex-grow: 0;}
            .class-card {min-width: 250px;}
            .dummy-card {display: none;} 
        }
        @media(max-width: 768px) {
            .grid-kelas {
                grid-template-columns: 1fr 1fr; 
            }
        }
        @media(max-width: 500px) {
            .grid-kelas {
                grid-template-columns: 1fr; 
            }
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="logo-area">
        <i class="fas fa-graduation-cap"></i>
        <div class="logo">AbsensiKelas</div>
    </div>
    <ul class="nav-links">
        <li><a href="home2.php" class="active">Home</a></li>
        <li><a href="http://localhost/Sistem_Absensi_Kelas/halaman_utama/index.php">Absensi</a></li>
        <li><a href="http://localhost/Sistem_Absensi_Kelas/profil_diri/profil.php">Profil Diri</a></li>
        <li><a href="http://localhost/Sistem_Absensi_Kelas/profil_diri/laporan.php">Laporan</a></li>
    </ul>
    <div class="profile-area">
        <div class="profile">
            <img src="<?= htmlspecialchars($foto_profil) ?>" 
                  alt="Profil" 
                  id="profile-trigger">
                  
            <div class="dropdown" id="profile-dropdown">
                <a href="http://localhost/Sistem_Absensi_Kelas/profil_diri/profil.php">Profil Saya (<?= htmlspecialchars($userData['nama'] ?? $username) ?>)</a>
                <a href="http://localhost/Sistem_Absensi_Kelas/profil_diri/pengaturan.php">Pengaturan</a>
                <a href="../Login2/logout.php">Logout</a>
            </div>
        </div>
    </div>
</nav>

<div class="main-container">
    
    <div class="content-left">
        
        <div class="welcome-title">
            <h1><span>Hi, <?= htmlspecialchars($userData['nama'] ?? $username) ?>!</span> 👋</h1>
            <p>Selamat datang kembali di dashboard absensi, semoga harimu menyenangkan.</p>
        </div>

        <div class="class-list-container" style="margin-bottom: 30px; padding: 15px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);">
            <h3 style="font-size: 18px; color: var(--primary-color); border-bottom: 2px solid var(--primary-color); padding-bottom: 8px; margin-bottom: 15px; font-weight: 600;"><i class="fas fa-chart-bar" style="margin-right: 8px;"></i> Leaderboard hari ini</h3>
            <div style="display: flex; gap: 20px; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 150px; padding: 15px; border-radius: 10px; background: var(--primary-color); color: white; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
                    <h4 style="font-size: 24px; font-weight: 700; margin-bottom: 5px;">XII-5</h4>
                    <p style="font-size: 14px; margin: 0; opacity: 0.9;">Kelas Terambis</p>
                </div>
                <div style="flex: 1; min-width: 150px; padding: 15px; border-radius: 10px; background: #FFC107; color: var(--text-color); box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
                    <h4 style="font-size: 24px; font-weight: 700; margin-bottom: 5px;">John Doe</h4>
                    <p style="font-size: 14px; margin: 0; opacity: 0.9;">Siswa Terambis</p>
                </div>
                <div style="flex: 1; min-width: 150px; padding: 15px; border-radius: 10px; background: var(--secondary-accent); color: white; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
                    <h4 style="font-size: 24px; font-weight: 700; margin-bottom: 5px;">Jane Doe</h4>
                    <p style="font-size: 14px; margin: 0; opacity: 0.9;">Siswi Terambis</p>
                </div>
            </div>
        </div>

        <div class="class-list-container">
            <h2><i class="fas fa-calendar-alt"></i> Jadwal Kelas Harian</h2>
            
            <div class="grid-kelas">
                
                <?php foreach ($daftar_kelas as $kelas): ?>
                
                <a href="<?= htmlspecialchars($kelas['file']) ?>" target="_blank" class="class-card-link">
                    <div class="class-card-grid">
                        <i class="fas fa-book-open"></i>
                        <h4><?= htmlspecialchars($kelas['nama']) ?></h4>
                        <p>Klik untuk melihat jadwal</p>
                    </div>
                </a>
                
                <?php endforeach; ?>
                
            </div>
        </div>
        
    </div>

    <div class="content-right">
        <div class="recent-classes">
            <h2>Kelas yang Baru Diakses</h2>
            <div class="class-list">
                <div class="class-card">
                    <h4>Kelas X - 1</h4>
                    <p>Terakhir diakses: 1 jam lalu</p>
                </div>
                <div class="class-card">
                    <h4>Kelas XI - 3</h4>
                    <p>Terakhir diakses: 3 jam lalu</p>
                </div>
                <div class="class-card">
                    <h4>Kelas XII - 2</h4>
                    <p>Terakhir diakses: Kemarin</p>
                </div>
                <div class="class-card">
                    <h4>Kelas X - 3</h4>
                    <p>Terakhir diakses: 2 hari lalu</p>
                </div>
                <div class="class-card">
                    <h4>Kelas XI - 1</h4>
                    <p>Terakhir diakses: 2 hari lalu</p>
                </div>
                <div class="class-card">
                    <h4>Kelas X - 2</h4>
                    <p>Terakhir diakses: 3 hari lalu</p>
                </div>
                <div class="dummy-card">
                    <p>... Riwayat Kelas Lainnya ...</p>
                </div>
            </div>
        </div>
    </div>

</div> 

<script>
    // === LOGIKA JAVASCRIPT BARU: Mengubah Dropdown dari Hover ke Click ===
    document.addEventListener('DOMContentLoaded', function() {
        const profileTrigger = document.getElementById('profile-trigger');
        const profileDropdown = document.getElementById('profile-dropdown');
        const profileArea = document.querySelector('.profile');

        // 1. Toggle Dropdown saat tombol profil diklik
        profileTrigger.addEventListener('click', function(e) {
            e.stopPropagation(); // Mencegah event mencapai body saat mengklik tombol
            profileDropdown.classList.toggle('active');
        });

        // 2. Sembunyikan Dropdown saat mengklik di luar area dropdown
        document.addEventListener('click', function(e) {
            // Cek apakah yang diklik BUKAN bagian dari profile-area
            if (profileDropdown.classList.contains('active') && !profileArea.contains(e.target)) {
                profileDropdown.classList.remove('active');
            }
        });

        // Script untuk scroll horizontal pada Recent Classes (Hanya berlaku saat layar kecil)
        const recentList = document.querySelector('.class-list');
        if (window.innerWidth < 1024) {
            recentList.addEventListener('wheel', (e) => {
                if (e.deltaY !== 0) {
                    e.preventDefault();
                    // Gunakan deltaY untuk scroll horizontal
                    e.currentTarget.scrollLeft += e.deltaY * 0.5;
                }
            }, { passive: false });
        }
    });

    
</script>
</body>
</html>