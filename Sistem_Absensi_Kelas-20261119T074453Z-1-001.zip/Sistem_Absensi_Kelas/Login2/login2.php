<?php
session_start();
include '../Koneksi.php';

/* ============================================================
   AUTO LOGIN (Remember Me)
   ============================================================ */
if (!isset($_SESSION['username']) && isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];

    $stmt = $conn->prepare(
        "SELECT * FROM users 
         WHERE remember_token=? 
         AND token_expires_at > NOW()"
    );
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        $_SESSION['username'] = $user['username'];
        $_SESSION['level']    = $user['level'];
        $_SESSION['id_user']  = $user['id_user'];

        if ($user['level'] == 'admin') {
            header("Location: ../Admin/admin.php");
        } else {
            header("Location: ../Home2/home2.php");
        }
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width , initial-scale=1.0">
    <title>Login!</title>
    <link rel="stylesheet" href="login2.css">

    <style>
        /* Tambahan CSS untuk pesan error */
        .alert {
            padding: 10px 15px;
            border-radius: 10px;
            font-weight: 500;
            margin-bottom: 15px;
            animation: fadeIn 0.5s ease;
        }
        .alert.error {
            background: rgba(255, 0, 0, 0.15);
            color: #ff4d4d;
            border: 1px solid rgba(255, 0, 0, 0.3);
        }
        .alert.success {
            background: rgba(0, 255, 0, 0.15);
            color: #4dff4d;
            border: 1px solid rgba(0, 255, 0, 0.3);
        }
        .alert.info {
            background: rgba(0, 128, 255, 0.15);
            color: #66b3ff;
            border: 1px solid rgba(0, 128, 255, 0.3);
        }
        @keyframes fadeIn {
            from {opacity: 0; transform: translateY(-5px);}
            to {opacity: 1; transform: translateY(0);}
        }
    </style>
</head>
<body>

<div class="login-box">
    <form action="cek.php" method="post">
        <div class="login-header">
            <header>Welcome</header>
            
        </div>

        <?php
        // Pesan error/sukses/login
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "gagal") {
                echo "<div class='alert error'>Login gagal! Username atau password salah!</div>";
            } else if ($_GET['pesan'] == "logout") {
                echo "<div class='alert success'>Anda telah berhasil logout.</div>";
            } else if ($_GET['pesan'] == "belum_login") {
                echo "<div class='alert info'>Anda harus login terlebih dahulu.</div>";
            }
        }
        ?>

        <div class="input-box">
            <input type="text" class="input-field" id="email" name="username" required>
            <label for="email">Username</label>
        </div>

        <div class="input-box">
            <input type="password" class="input-field" id="password" name="password" required>
            <label for="password">Password</label>
        </div>

        <div class="forgot">
            <section>
                <input type="checkbox" id="check" name="remember_me">
                <label for="check">Remember me?</label>
            </section>
        </div>

        <div class="input-box">
            <input type="submit" class="input-submit" value="Login">
        </div>

        <div class="Register">
            <p>Don't have account? <a href="register.php">Register</a></p>
        </div>

        <script>
            // Cursor blur animation
            const blurCircle = document.createElement('div');
            blurCircle.className = 'cursor-blur';
            document.body.appendChild(blurCircle);

            const submitButton = document.querySelector('.input-submit');
            submitButton.addEventListener('mouseenter', () => blurCircle.style.opacity = '1');
            submitButton.addEventListener('mouseleave', () => blurCircle.style.opacity = '0');
            submitButton.addEventListener('mousemove', (event) => {
                const rect = submitButton.getBoundingClientRect();
                const x = event.clientX - rect.left - blurCircle.offsetWidth / 2;
                const y = event.clientY - rect.top - blurCircle.offsetHeight / 2;
                blurCircle.style.left = `${x + rect.left}px`;
                blurCircle.style.top = `${y + rect.top}px`;
            });
        </script>
    </form>
</div>

</body>
</html>
