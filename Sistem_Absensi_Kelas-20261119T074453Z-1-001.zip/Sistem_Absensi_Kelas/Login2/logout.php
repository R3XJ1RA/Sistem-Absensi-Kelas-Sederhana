<?php
session_start(); // Mulai session

// Hapus semua data session
session_unset();
session_destroy();

// Arahkan kembali ke halaman login dengan pesan sukses logout
header("Location: login2.php?pesan=logout");
exit();
?>
