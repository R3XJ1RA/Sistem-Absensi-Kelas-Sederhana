<?php
include '../Koneksi.php'; // Pastikan file koneksi kamu sudah ada

$status_message = '';
$status_class = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data input
    $username = $conn->real_escape_string(trim($_POST['username']));
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $alamat = $conn->real_escape_string(trim($_POST['alamat']));
    $foto_profil = 'default.png'; // default jika tidak upload

    // Validasi dasar
    if (empty($username) || empty($password) || empty($confirm_password)) {
        $status_message = "Semua bidang wajib diisi.";
        $status_class = 'alert-warning';
    } elseif ($password !== $confirm_password) {
        $status_message = "Password dan konfirmasi tidak cocok.";
        $status_class = 'alert-danger';
    } elseif (strlen($password) < 6) {
        $status_message = "Password minimal 6 karakter.";
        $status_class = 'alert-danger';
    } else {
        // Cek apakah username sudah ada
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $status_message = "Username sudah terdaftar.";
            $status_class = 'alert-danger';
        } else {
            // Upload foto profil (opsional)
            if (isset($_FILES['foto_profil']) && $_FILES['foto_profil']['error'] == 0) {
                $target_dir = "uploads/";
                $file_name = basename($_FILES["foto_profil"]["name"]);
                $imageFileType = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                $new_file_name = $username . '_' . time() . '.' . $imageFileType;
                $target_file = $target_dir . $new_file_name;

                if (!is_dir($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }

                if ($_FILES["foto_profil"]["size"] > 1000000) {
                    $status_message = "Ukuran file maksimal 1MB.";
                    $status_class = 'alert-danger';
                } elseif (!in_array($imageFileType, ['jpg', 'jpeg', 'png'])) {
                    $status_message = "Hanya JPG, JPEG, dan PNG yang diperbolehkan.";
                    $status_class = 'alert-danger';
                } elseif (move_uploaded_file($_FILES["foto_profil"]["tmp_name"], $target_file)) {
                    $foto_profil = $new_file_name;
                } else {
                    $status_message = "Gagal mengunggah file.";
                    $status_class = 'alert-danger';
                }
            }

            // Jika tidak ada error, simpan ke database
            if (empty($status_message) || $status_class !== 'alert-danger') {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt_insert = $conn->prepare("INSERT INTO users (username, password, alamat, foto_profil) VALUES (?, ?, ?, ?)");
                $stmt_insert->bind_param("ssss", $username, $hashed_password, $alamat, $foto_profil);

                if ($stmt_insert->execute()) {
                    header("Location: login2.php?pesan=signup_berhasil");
                    exit;
                } else {
                    $status_message = "Kesalahan database: " . $stmt_insert->error;
                    $status_class = 'alert-danger';
                }
                $stmt_insert->close();
            }
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTER</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        * {margin:0;padding:0;box-sizing:border-box;font-family:"Poppins",sans-serif!important;}
        body {
            min-height:100vh;
            background:url("images.jpg") no-repeat center center fixed;
            background-size:cover;
            display:flex;align-items:center;justify-content:center;
            padding:40px 10px;
        }
        .register-box {
            background:rgba(255,255,255,0.18);
            backdrop-filter:blur(14px);
            border-radius:20px;
            box-shadow:0 6px 30px rgba(0,0,0,0.3);
            border:1px solid rgba(255,255,255,0.3);
            padding:40px 50px;
            max-width:850px;
            width:95%;
            color:#0a2647;
            transition:transform .3s;
        }
        .register-box:hover {transform:translateY(-4px);}
        .register-header{text-align:center;margin-bottom:25px;}
        .register-header h2{font-weight:700;font-size:30px;}
        input.form-control, textarea.form-control {
            border:none;border-bottom:2px solid rgba(10,38,71,0.4);
            background:transparent;color:#0a2647;
            transition:.3s;font-size:15px;
        }
        input.form-control:focus,textarea.form-control:focus{
            border-bottom-color:#0a2647;box-shadow:none;
        }
        textarea.form-control{resize:vertical;border:2px solid rgba(10,38,71,0.4);border-radius:8px;background:rgba(255,255,255,0.1);}
        .profile-placeholder {
            width:150px;height:150px;background-color:rgba(255,255,255,0.25);
            border-radius:50%;display:flex;align-items:center;justify-content:center;
            font-size:4rem;color:#0a2647;margin:0 auto 15px;
            border:2px dashed rgba(10,38,71,0.3);
        }
        .btn-custom {background-color:#0a2647;color:#fff;border:none;border-radius:8px;padding:6px 1rem;cursor:pointer;}
        .btn-custom:hover{background-color:#133b6b;}
        .input-submit {
            width:100%;padding:12px;border:none;background:#0a2647;color:#fff;
            font-size:16px;border-radius:8px;cursor:pointer;transition:.3s;margin-top:20px;
        }
        .input-submit:hover {background:#133b6b;transform:scale(1.02);}
        .register-footer{text-align:center;margin-top:20px;color:#0a2647;}
        .register-footer a{color:#0a2647;font-weight:600;text-decoration:none;}
        .register-footer a:hover{text-decoration:underline;}
    </style>
    <script>
        function validasi() {
            var password = document.getElementById("password").value;
            var confirm = document.getElementById("confirm_password").value;
            if (password !== confirm) {
                alert("Password dan konfirmasi password tidak cocok!");
                return false;
            }
            return true;
        }
    </script>
</head>

<body>
<div class="register-box">
    <div class="register-header">
        <h2>Registrasi Akun</h2>
        <p>Silakan isi data berikut untuk membuat akun baru</p>
    </div>

    <?php if ($status_message): ?>
        <div class="alert <?= $status_class ?> text-center" role="alert">
            <?= $status_message ?>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" onsubmit="return validasi()">
        <div class="row">
            <div class="col-md-8">
                <div class="mb-3 row align-items-center">
                    <label for="username" class="col-sm-4 col-form-label text-end">Username :</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                </div>
                <div class="mb-3 row align-items-center">
                    <label for="password" class="col-sm-4 col-form-label text-end">Password :</label>
                    <div class="col-sm-8">
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                </div>
                <div class="mb-3 row align-items-center">
                    <label for="confirm_password" class="col-sm-4 col-form-label text-end">Konfirmasi Password :</label>
                    <div class="col-sm-8">
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                </div>
                <div class="mb-3 row align-items-start">
                    <label for="alamat" class="col-sm-4 col-form-label text-end">Alamat :</label>
                    <div class="col-sm-8">
                        <textarea name="alamat" id="alamat" rows="3" class="form-control" placeholder="Domisili Anda"></textarea>
                    </div>
                </div>
            </div>

            <div class="col-md-4 text-center border-start">
                <div class="profile-placeholder">
                    <i class="fas fa-user"></i>
                </div>
                <div class="input-group mb-3 justify-content-center">
                    <label class="btn btn-custom" for="inputGroupFile02">Pilih File</label>
                    <input type="file" id="inputGroupFile02" name="foto_profil" hidden>
                    <span class="input-group-text file-name-display">Tidak ada file</span>
                </div>
                <small class="text-muted" style="font-size: 0.75rem;">Pilih foto PNG/JPG/JPEG (max 1 MB)</small>
            </div>
        </div>
        <button type="submit" class="input-submit">Daftar Sekarang</button>
    </form>

    <div class="register-footer">
        <p>Sudah punya akun? <a href="login2.php">Masuk di sini</a></p>
    </div>
</div>

<script>
    document.getElementById('inputGroupFile02').addEventListener('change', function(e) {
        var fileName = e.target.files[0] ? e.target.files[0].name : 'Tidak ada file';
        document.querySelector('.file-name-display').textContent = fileName;
    });
</script>
</body>
</html>
