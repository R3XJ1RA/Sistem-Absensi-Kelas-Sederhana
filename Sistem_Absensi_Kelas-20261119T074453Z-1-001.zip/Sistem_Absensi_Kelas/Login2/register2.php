<?php
// Mulai sesi
session_start();
// Pastikan file Koneksi.php sudah tersedia dan berisi variabel $conn
include '../Koneksi.php';

// Cek jika pengguna sudah login, arahkan ke halaman utama yang sesuai
if (isset($_SESSION['username'])) {
    if ($_SESSION['level'] == 'admin') {
        header("Location: ../Admin/admin.php");
    } else {
        header("Location: ../Home2/home2.php");
    }
    exit();
}

// Inisialisasi variabel untuk pesan feedback dan nilai input (Sticky Form)
$pesan = '';
$tipe_pesan = '';
$username = ''; // Inisialisasi untuk Sticky Form
$email = '';    // Inisialisasi untuk Sticky Form

/* ============================================================
    PROSES PENDAFTARAN (POST REQUEST)
    ============================================================ */

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari formulir dan bersihkan
    $username = trim($_POST['username']);
    $password_plain = $_POST['password']; // Password mentah
    $email = trim($_POST['email']);
    $remember_me = isset($_POST['remember_me']);
    
    // Validasi dasar
    if (empty($username) || empty($password_plain) || empty($email)) {
        $pesan = "Semua field harus diisi!";
        $tipe_pesan = 'red';
    } else {
        // 1. Cek apakah username atau email sudah terdaftar
        $stmt_check = $conn->prepare("SELECT id_user FROM users WHERE username = ? OR email = ?");
        $stmt_check->bind_param("ss", $username, $email);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            $pesan = "Username atau Email sudah terdaftar, silakan gunakan yang lain.";
            $tipe_pesan = 'red';
            // Nilai $username dan $email dipertahankan untuk ditampilkan kembali di form
        } else {
            // 2. Hash Password
            $password_hash = password_hash($password_plain, PASSWORD_DEFAULT);
            $level = 'user'; // Default level saat registrasi

            $remember_token = null;
            $token_expires_at = null;

            // 3. Masukkan data ke database
            $stmt_insert = $conn->prepare(
                "INSERT INTO users (username, password, email, level, remember_token, token_expires_at) 
                 VALUES (?, ?, ?, ?, ?, ?)"
            );
            $stmt_insert->bind_param("ssssss", 
                $username, 
                $password_hash, 
                $email, 
                $level, 
                $remember_token, 
                $token_expires_at
            );

            if ($stmt_insert->execute()) {
                $pesan = "Pendaftaran berhasil! Anda akan diarahkan untuk Login.";
                $tipe_pesan = 'green';
                
                // Hapus nilai $username dan $email setelah berhasil agar form kosong
                $username = '';
                $email = '';
                
                // Redirect ke halaman login setelah 3 detik
                header("refresh:3;url=login2.php");
            } else {
                $pesan = "Pendaftaran gagal. Error: " . $conn->error;
                $tipe_pesan = 'red';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width , initial-scale=1.0">
    <title>Register!</title>
    <link rel="stylesheet" href="login2.css"> 
</head>
<body>

<?php
// Tampilkan pesan feedback (berhasil/gagal)
if ($pesan) {
    echo "<p style='color:{$tipe_pesan}; text-align:center; padding: 10px; position: fixed; top: 10px; left: 50%; transform: translateX(-50%); background: white; z-index: 1000; border-radius: 5px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>{$pesan}</p>";
}
?>

<div class="login-box">
    <form action="register2.php" method="post"> 
        <div class="login-header">
            <header>Create Account</header>
            <p>Join us today!</p>
        </div>

        <div class="input-box">
            <input type="text" class="input-field" id="username" name="username" required 
                   value="<?php echo htmlspecialchars($username); ?>"
                   placeholder=" " > 
            <label for="username">Username</label>
        </div>
        
         <div class="input-box">
            <input type="email" class="input-field" id="email" name="email" required
                   placeholder=" " > 
            <label for="email">email</label>
        </div>

        <div class="input-box">
            <input type="password" class="input-field" id="password" name="password" required
                   placeholder=" " > 
            <label for="password">Password</label>
        </div>
        
        <div class="forgot">
            <section>
                <input type="checkbox" id="check" name="remember_me" 
                       <?php echo isset($_POST['remember_me']) ? 'checked' : ''; ?>>
                <label for="check">Remember me?</label>
            </section>
        </div>

        <div class="input-box">
            <input type="submit" class="input-submit" value="Register">
        </div>

        <div class="Register">
            <p>Already have an account? <a href="login2.php">Login</a></p>
        </div>

        <script>
            // Skrip JavaScript untuk efek kursor
            const blurCircle = document.createElement('div');
            blurCircle.className = 'cursor-blur';
            document.body.appendChild(blurCircle);

            const submitButton = document.querySelector('.input-submit');

            submitButton.addEventListener('mouseenter', () => {
                blurCircle.style.opacity = '1';
            });

            submitButton.addEventListener('mouseleave', () => {
                blurCircle.style.opacity = '0';
            });

            submitButton.addEventListener('mousemove', (event) => {
                const rect = submitButton.getBoundingClientRect();
                const x = event.clientX - rect.left - blurCircle.offsetWidth / 2;
                const y = event.clientY - rect.top - blurCircle.offsetHeight / 2;
                blurCircle.style.left = `${x + rect.left}px`;
                blurCircle.style.top = `${y + rect.top}px`;
            });
        </script>
    </form>
</div>

</body>
</html>