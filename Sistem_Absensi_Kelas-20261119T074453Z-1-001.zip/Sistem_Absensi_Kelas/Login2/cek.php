<?php
session_start();
include '../Koneksi.php'; // pastikan path benar

$username = $_POST['username'];
$password = $_POST['password'];
$remember = isset($_POST['remember_me']);

// Ambil data user dari database
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    // Verifikasi password
    if (password_verify($password, $user['password'])) {
        // Simpan session
        $_SESSION['username'] = $user['username'];
        $_SESSION['level'] = $user['level'];
        $_SESSION['id_user'] = $user['id_user'];

        // =========================
        // 🔐 REMEMBER ME
        // =========================
        if ($remember) {
            $token = bin2hex(random_bytes(16));
            $expires = date('Y-m-d H:i:s', strtotime('+7 days'));

            // Simpan token di database
            $stmt_token = $conn->prepare("UPDATE users SET remember_token=?, token_expires_at=? WHERE id_user=?");
            $stmt_token->bind_param("ssi", $token, $expires, $user['id_user']);
            $stmt_token->execute();

            // Simpan token di cookie
            setcookie('remember_token', $token, time() + (86400 * 7), "/", "", false, true); // 7 hari
        }

        // =========================
        // 🌐 REDIRECT KE DOMAIN LAIN
        // =========================
        if ($user['level'] == 'admin') {
            header("Location: http://localhost/Sistem_Absensi_Kelas/Home2/home2.php");
        } else {
            header("Location: http://localhost/Sistem_Absensi_Kelas/Home2/home2.php");
        }
        exit;
    } else {
        header("Location: login2.php?pesan=gagal");
        exit;
    }
} else {
    header("Location: login2.php?pesan=gagal");
    exit;
}
?>
