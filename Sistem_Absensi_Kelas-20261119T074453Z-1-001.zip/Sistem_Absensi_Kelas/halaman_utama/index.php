<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pilih Kelas</title>

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: url('images.jpg') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .card {
            width: 380px;
            background: rgba(255,255,255,0.15);
            padding: 30px 30px 40px;
            border-radius: 16px;
            backdrop-filter: blur(10px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            color: white;
            text-align: center;
            position: relative;
        }

        /* Tombol kembali di tengah atas */
        a.back {
            display: inline-block;
            color: black;
            font-size: 18px;
            text-decoration: none;
            opacity: 0.85;
            font-weight: 600;
            background: rgba(255,255,255,0.8);
            padding: 8px 20px;
            border-radius: 10px;
            margin-bottom: 15px;
            transition: 0.3s;
        }

        a.back:hover {
            background: white;
            opacity: 1;
            transform: scale(1.05);
        }

        h2 {
            font-weight: 600;
            margin: 15px 0 25px;
            font-size: 26px;
        }

        .class-option {
            display: block;
            background: rgba(255,255,255,0.85);
            color: #333;
            text-decoration: none;
            padding: 15px;
            margin: 10px 0;
            border-radius: 12px;
            font-weight: 600;
            font-size: 18px;
            transition: 0.3s;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }

        .class-option:hover {
            background: white;
            transform: translateY(-3px);
        }
    </style>
</head>
<body>

<div class="card">
    <!-- Tombol kembali di tengah -->
    <a href="http://localhost/Sistem_Absensi_Kelas/Home2/home2.php" class="back">← Kembali</a>

    <h2>Pilih Kelas</h2>

    <a href="absenX.php?tingkatan=X" class="class-option">Kelas X</a>
    <a href="absenXI.php?tingkatan=XI" class="class-option">Kelas XI</a>
    <a href="absenXII.php?tingkatan=XII" class="class-option">Kelas XII</a>
</div>

</body>
</html>
