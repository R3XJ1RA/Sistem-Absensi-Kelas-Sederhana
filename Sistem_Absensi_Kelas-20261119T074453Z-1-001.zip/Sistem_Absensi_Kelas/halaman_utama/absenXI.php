<?php
include '../Koneksi.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Asia/Jakarta');

if (isset($_POST['submit'])) {
    $nama    = trim($_POST['nama']);
    $kelas   = $_POST['kelas'];
    $status  = $_POST['status'];
    $alasan  = $_POST['alasan'];
    $jam     = date("H:i:s");
    $tanggal = date("Y-m-d");

    if ($nama == "" || $status == "" || $kelas == "") {
        echo "<script>alert('Semua field wajib diisi');</script>";
    } else {
        $sql = "INSERT INTO siswa (nama, kelas, jam_masuk, status, alasan, tanggal)
                VALUES ('$nama', '$kelas', '$jam', '$status', '$alasan', '$tanggal')";

        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Absensi Berhasil!');</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Form Absensi</title>

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: url('images.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .card {
            width: 380px;
            background: rgba(255,255,255,0.15);
            padding: 30px 30px 40px;
            border-radius: 16px;
            backdrop-filter: blur(10px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            color: white;
            text-align: center;
            position: relative;
        }

        /* Tombol kembali di tengah atas */
        a.back {
            display: inline-block;
            color: black;
            font-size: 18px;
            text-decoration: none;
            opacity: 0.85;
            font-weight: 600;
            background: rgba(255,255,255,0.8);
            padding: 8px 20px;
            border-radius: 10px;
            margin-bottom: 15px;
            transition: 0.3s;
        }

        a.back:hover {
            background: white;
            opacity: 1;
            transform: scale(1.05);
        }

        h2 {
            font-weight: 600;
            margin-bottom: 10px;
        }

        #clock {
            font-size: 34px;
            font-weight: 600;
            margin-bottom: 25px;
            letter-spacing: 2px;
            text-shadow: 0 0 8px rgba(255,255,255,0.6);
        }

        input, select, textarea {
            width: 100%;
            padding: 12px;
            margin-top: 8px;
            margin-bottom: 18px;
            border-radius: 10px;
            border: none;
            background: rgba(255,255,255,0.25);
            color: white;
            outline: none;
            backdrop-filter: blur(5px);
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            box-sizing: border-box;
        }

        input, select {
            height: 45px;
        }

        textarea {
            height: 90px;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        input::placeholder, textarea::placeholder {
            color: #eaeaea;
        }

        select option {
            color: black;
            background: white;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #ffffff;
            color: #333;
            font-weight: 600;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            transition: .25s;
            font-size: 16px;
        }

        button:hover {
            background: #dcdcdc;
            transform: scale(1.03);
        }
    </style>

    <script>
        function updateClock() {
            let now = new Date();
            document.getElementById("clock").innerHTML =
                now.getHours().toString().padStart(2,"0") + ":" +
                now.getMinutes().toString().padStart(2,"0") + ":" +
                now.getSeconds().toString().padStart(2,"0");
        }
        setInterval(updateClock, 1000);
    </script>

</head>
<body onload="updateClock()">

<div class="card">
    <!-- Tombol kembali di tengah atas -->
    <a href="index.php" class="back">← Kembali</a>

    <h2>Absensi</h2>

    <div id="clock"></div>

    <form method="POST">
        <input type="text" name="nama" placeholder="Nama Lengkap" required>

        <select name="kelas" required>
            <option value="">-- Pilih Kelas --</option>
            <option value="X.1">XI.1</option>
            <option value="X.2">XI.2</option>
            <option value="X.3">XI.3</option>
        </select>

        <select name="status" required>
            <option value="">-- Pilih Status --</option>
            <option value="Hadir">Hadir</option>
            <option value="Izin">Izin</option>
            <option value="Sakit">Sakit</option>
        </select>

        <textarea name="alasan" placeholder="Alasan (Jika tidak hadir)"></textarea>

        <button type="submit" name="submit">Submit Absensi</button>
    </form>
</div>

</body>
</html>
