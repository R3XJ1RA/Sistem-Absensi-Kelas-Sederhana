<?php
include 'koneksi.php';

$tingkatan = $_GET['tingkatan'];
$kelas     = $_GET['kelas'];

$sql = "SELECT * FROM siswa 
        WHERE tingkatan='$tingkatan' AND kelas='$kelas'
        ORDER BY tanggal DESC, jam_masuk DESC";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Absensi</title>
</head>
<body>

<h2>Data Absensi: <?= $tingkatan ?> - <?= $kelas ?></h2>

<table border="1" cellpadding="8">
    <tr>
        <th>Nama</th>
        <th>Status</th>
        <th>Alasan</th>
        <th>Jam Masuk</th>
        <th>Tanggal</th>
    </tr>

    <?php while ($d = mysqli_fetch_assoc($result)) : ?>
        <tr>
            <td><?= $d['nama'] ?></td>
            <td><?= $d['status'] ?></td>
            <td><?= $d['alasan'] ?></td>
            <td><?= $d['jam_masuk'] ?></td>
            <td><?= $d['tanggal'] ?></td>
        </tr>
    <?php endwhile; ?>

</table>

</body>
</html>
